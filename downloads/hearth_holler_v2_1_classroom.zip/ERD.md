# Hearth & Holler v2.1 ERD

Portable Mermaid source; composite key details and constraint names are in the dictionary.

```mermaid
erDiagram
    store_region {
        TINYINT_UNSIGNED region_id PK
        VARCHAR_60_ region_name
        VARCHAR_60_ regional_office_city
        VARCHAR_255_ description
    }
    store {
        SMALLINT_UNSIGNED store_id PK
        TINYINT_UNSIGNED region_id
        CHAR_4_ store_number
        VARCHAR_100_ store_name
        VARCHAR_120_ street_address
        VARCHAR_60_ city
        CHAR_2_ state_code
        CHAR_5_ postal_code
        VARCHAR_20_ phone
        DATE opened_date
        INT_UNSIGNED square_feet
        BOOLEAN is_active
    }
    department {
        TINYINT_UNSIGNED department_id PK
        VARCHAR_60_ department_name
        VARCHAR_255_ description
    }
    job_role {
        TINYINT_UNSIGNED job_role_id PK
        VARCHAR_60_ role_name
        DECIMAL_6_2_ minimum_hourly_rate
        DECIMAL_6_2_ maximum_hourly_rate
        BOOLEAN is_management
    }
    employee {
        INT_UNSIGNED employee_id PK
        SMALLINT_UNSIGNED store_id
        TINYINT_UNSIGNED job_role_id
        TINYINT_UNSIGNED department_id
        INT_UNSIGNED manager_employee_id
        VARCHAR_50_ first_name
        VARCHAR_50_ last_name
        DATE hire_date
        DECIMAL_6_2_ hourly_rate
        VARCHAR_120_ email
        ENUM__ACTIVE____LEAVE____FORMER__ employment_status
    }
    category {
        TINYINT_UNSIGNED category_id PK
        TINYINT_UNSIGNED department_id
        VARCHAR_60_ category_name
        ENUM__PERISHABLE____SEMI_PERISHABLE____SHELF_STABLE__ shelf_life_class
    }
    brand {
        SMALLINT_UNSIGNED brand_id PK
        VARCHAR_80_ brand_name
        VARCHAR_160_ brand_tagline
        VARCHAR_60_ home_city
        CHAR_2_ home_state_code
        BOOLEAN is_store_brand
    }
    product {
        INT_UNSIGNED product_id PK
        SMALLINT_UNSIGNED brand_id
        TINYINT_UNSIGNED category_id
        VARCHAR_20_ sku
        CHAR_12_ upc
        VARCHAR_120_ product_name
        VARCHAR_40_ package_size
        ENUM__EACH____OUNCE____POUND____FLUID_OUNCE____COUNT__ unit_of_measure
        DECIMAL_8_2_ list_price
        DECIMAL_8_2_ unit_cost
        BOOLEAN is_active
        DATE introduced_date
        ENUM__RESALE___INGREDIENT___PACKAGING___PREPARED___BAR__ product_type
        DECIMAL_5_4_ tax_rate
        BOOLEAN is_sellable
        ENUM__ALL___BREAKFAST___LUNCH__ food_period
    }
    supplier {
        SMALLINT_UNSIGNED supplier_id PK
        VARCHAR_100_ supplier_name
        VARCHAR_100_ contact_name
        VARCHAR_20_ phone
        VARCHAR_120_ email
        VARCHAR_60_ city
        CHAR_2_ state_code
        TINYINT_UNSIGNED lead_time_days
        DECIMAL_3_2_ supplier_rating
        BOOLEAN is_active
    }
    product_supplier {
        INT_UNSIGNED product_id PK
        SMALLINT_UNSIGNED supplier_id PK
        VARCHAR_30_ supplier_product_code
        DECIMAL_8_2_ wholesale_cost
        BOOLEAN is_primary_supplier
        SMALLINT_UNSIGNED minimum_order_quantity
    }
    store_inventory {
        SMALLINT_UNSIGNED store_id PK
        INT_UNSIGNED product_id PK
        INT_UNSIGNED quantity_on_hand
        DECIMAL_14_2_ inventory_value
        INT_UNSIGNED reorder_point
        INT_UNSIGNED reorder_quantity
        VARCHAR_20_ shelf_location
        DATETIME last_counted_at
    }
    customer {
        INT_UNSIGNED customer_id PK
        VARCHAR_50_ first_name
        VARCHAR_50_ last_name
        VARCHAR_120_ email
        VARCHAR_20_ phone
        VARCHAR_60_ city
        CHAR_2_ state_code
        CHAR_5_ postal_code
        YEAR birth_year
        DATETIME created_at
        BOOLEAN marketing_opt_in
    }
    loyalty_account {
        INT_UNSIGNED loyalty_account_id PK
        INT_UNSIGNED customer_id
        CHAR_10_ loyalty_number
        DATE joined_date
        INT_UNSIGNED points_balance
        ENUM__SPROUT____SAPLING____MIGHTY_OAK__ tier
    }
    payment_method {
        TINYINT_UNSIGNED payment_method_id PK
        VARCHAR_40_ method_name
        DECIMAL_5_4_ processing_fee_rate
    }
    sale {
        BIGINT_UNSIGNED sale_id PK
        SMALLINT_UNSIGNED store_id
        INT_UNSIGNED customer_id
        INT_UNSIGNED employee_id
        DATETIME sold_at
        DATE trading_date
        ENUM__BREAKFAST___LUNCH___TOP_UP___WEEKLY___DINNER___BAR__ purchase_occasion
        ENUM__COMPLETED____RETURNED____VOIDED__ sale_status
        DECIMAL_10_2_ subtotal
        DECIMAL_10_2_ discount_total
        DECIMAL_10_2_ tax_total
        DECIMAL_10_2_ grand_total
    }
    sale_item {
        ENUM__GROCERY___GRIDDLE___GRAB_GO___BAR__ service_channel
        BIGINT_UNSIGNED sale_id PK
        SMALLINT_UNSIGNED line_number PK
        INT_UNSIGNED product_id
        SMALLINT_UNSIGNED quantity
        DECIMAL_8_2_ unit_price
        DECIMAL_8_2_ discount_amount
        DECIMAL_8_2_ tax_amount
        DECIMAL_12_2_ cost_amount
    }
    promotion {
        SMALLINT_UNSIGNED promotion_id PK
        VARCHAR_100_ promotion_name
        VARCHAR_255_ promotion_description
        DATE start_date
        DATE end_date
        ENUM__PERCENT____AMOUNT__ discount_type
        DECIMAL_8_2_ discount_value
    }
    product_promotion {
        SMALLINT_UNSIGNED promotion_id PK
        INT_UNSIGNED product_id PK
        BOOLEAN featured_display
    }
    inventory_adjustment {
        BIGINT_UNSIGNED adjustment_id PK
        SMALLINT_UNSIGNED store_id
        INT_UNSIGNED product_id
        INT_UNSIGNED employee_id
        DATETIME adjusted_at
        SMALLINT quantity_change
        ENUM__DELIVERY____DAMAGE____SPOILAGE____COUNT_CORRECTION____DONATION__ reason
        VARCHAR_255_ notes
    }
    purchase_order {
        INT_UNSIGNED purchase_order_id PK
        SMALLINT_UNSIGNED store_id
        SMALLINT_UNSIGNED supplier_id
        INT_UNSIGNED ordered_by_employee_id
        DATETIME ordered_at
        DATE expected_delivery_date
        ENUM__OPEN____PARTIALLY_RECEIVED____RECEIVED____CANCELLED__ purchase_order_status
    }
    purchase_order_line {
        INT_UNSIGNED purchase_order_id PK
        SMALLINT_UNSIGNED line_number PK
        INT_UNSIGNED product_id
        SMALLINT_UNSIGNED supplier_id
        SMALLINT_UNSIGNED quantity_ordered
        DECIMAL_8_2_ unit_cost
    }
    receipt {
        INT_UNSIGNED receipt_id PK
        INT_UNSIGNED purchase_order_id
        INT_UNSIGNED received_by_employee_id
        DATETIME received_at
        VARCHAR_40_ delivery_reference
    }
    receipt_line {
        INT_UNSIGNED receipt_id PK
        SMALLINT_UNSIGNED line_number PK
        INT_UNSIGNED purchase_order_id
        SMALLINT_UNSIGNED purchase_order_line_number
        SMALLINT_UNSIGNED quantity_received
    }
    sale_payment {
        BIGINT_UNSIGNED sale_id PK
        SMALLINT_UNSIGNED payment_sequence PK
        TINYINT_UNSIGNED payment_method_id
        DECIMAL_10_2_ amount
    }
    product_price_history {
        INT_UNSIGNED product_id PK
        DATE effective_start_date PK
        DECIMAL_8_2_ list_price
    }
    loyalty_transaction {
        INT_UNSIGNED loyalty_transaction_id PK
        INT_UNSIGNED loyalty_account_id
        BIGINT_UNSIGNED sale_id
        DATETIME transacted_at
        ENUM__EARN____REDEEM____ADJUST____EXPIRE__ transaction_type
        INT points_change
        VARCHAR_255_ notes
    }
    product_supplier_cost_history {
        INT_UNSIGNED product_id PK
        SMALLINT_UNSIGNED supplier_id PK
        DATE effective_start_date PK
        DECIMAL_8_2_ wholesale_cost
    }
    inventory_opening {
        SMALLINT_UNSIGNED store_id PK
        INT_UNSIGNED product_id PK
        DATETIME opened_at
        INT_UNSIGNED quantity
        DECIMAL_14_2_ inventory_value
    }
    sale_return {
        BIGINT_UNSIGNED sale_return_id PK
        BIGINT_UNSIGNED sale_id
        INT_UNSIGNED employee_id
        DATETIME returned_at
        VARCHAR_100_ reason
        DECIMAL_10_2_ net_amount
        DECIMAL_10_2_ tax_amount
        DECIMAL_10_2_ refund_total
    }
    sale_return_item {
        BIGINT_UNSIGNED sale_return_id PK
        SMALLINT_UNSIGNED line_number PK
        BIGINT_UNSIGNED sale_id
        SMALLINT_UNSIGNED sale_line_number
        SMALLINT_UNSIGNED quantity
        DECIMAL_10_2_ net_amount
        DECIMAL_10_2_ tax_amount
        DECIMAL_12_2_ cost_amount
    }
    sale_refund {
        BIGINT_UNSIGNED sale_return_id PK
        SMALLINT_UNSIGNED refund_sequence PK
        BIGINT_UNSIGNED sale_id
        SMALLINT_UNSIGNED payment_sequence
        DATETIME refunded_at
        DECIMAL_10_2_ amount
    }
    store_service_hours {
        SMALLINT_UNSIGNED store_id PK
        ENUM__RETAIL___GRIDDLE___KITCHEN___BAR___PACKAGE_BEER__ service PK
        TINYINT_UNSIGNED weekday_number PK
        TIME opens_at
        TIME closes_at
        TINYINT_UNSIGNED close_day_offset
    }
    store_product_price_history {
        SMALLINT_UNSIGNED store_id PK
        INT_UNSIGNED product_id PK
        DATE effective_start_date PK
        DECIMAL_8_2_ list_price
    }
    store_supplier {
        SMALLINT_UNSIGNED store_id PK
        SMALLINT_UNSIGNED supplier_id PK
        TINYINT_UNSIGNED delivery_days
    }
    recipe {
        INT_UNSIGNED recipe_id PK
        INT_UNSIGNED product_id
        VARCHAR_100_ recipe_name
        DECIMAL_6_2_ preparation_minutes
        SMALLINT_UNSIGNED shelf_life_hours
    }
    recipe_ingredient {
        INT_UNSIGNED recipe_id PK
        INT_UNSIGNED ingredient_product_id PK
        SMALLINT_UNSIGNED quantity_per_unit
    }
    production_batch {
        BIGINT_UNSIGNED production_batch_id PK
        SMALLINT_UNSIGNED store_id
        INT_UNSIGNED recipe_id
        ENUM__MADE_TO_ORDER___BATCH__ production_method
        DATETIME scheduled_at
        DATETIME started_at
        DATETIME completed_at
        DATETIME available_at
        DATETIME expires_at
        INT_UNSIGNED quantity_produced
        DECIMAL_12_2_ ingredient_cost
        DECIMAL_12_2_ packaging_cost
        DECIMAL_10_2_ labor_minutes
        BIGINT_UNSIGNED sale_id
        SMALLINT_UNSIGNED sale_line_number
    }
    production_input {
        BIGINT_UNSIGNED production_batch_id PK
        SMALLINT_UNSIGNED line_number PK
        INT_UNSIGNED ingredient_product_id
        INT_UNSIGNED quantity
        DECIMAL_12_2_ cost_amount
    }
    prepared_food_allocation {
        BIGINT_UNSIGNED production_batch_id PK
        BIGINT_UNSIGNED sale_id PK
        SMALLINT_UNSIGNED sale_line_number PK
        SMALLINT_UNSIGNED quantity
    }
    production_disposal {
        BIGINT_UNSIGNED production_batch_id PK
        BIGINT_UNSIGNED adjustment_id PK
        INT_UNSIGNED quantity
    }
    daily_labor {
        SMALLINT_UNSIGNED store_id PK
        DATE work_date PK
        TINYINT_UNSIGNED department_id PK
        TINYINT_UNSIGNED job_role_id PK
        DECIMAL_8_2_ paid_hours
        DECIMAL_7_2_ hourly_rate
        DECIMAL_12_2_ wage_amount
        DECIMAL_12_2_ employer_cost
        DECIMAL_12_2_ benefit_cost
    }
    dataset_metadata {
        TINYINT_UNSIGNED dataset_id PK
        ENUM__FIXTURE___CLASSROOM___FULL__ edition
        DATE reporting_start
        DATE reporting_end
        VARCHAR_40_ timezone_name
        INT_UNSIGNED seed
    }
    inventory_movement {
        BIGINT_UNSIGNED movement_id PK
        SMALLINT_UNSIGNED store_id
        INT_UNSIGNED product_id
        DATETIME moved_at
        ENUM__SALE___RECEIPT___RETURN___ADJUSTMENT___PRODUCTION_IN___PRODUCTION_OUT__ movement_type
        INT quantity_change
        DECIMAL_14_2_ value_change
        BIGINT_UNSIGNED sale_id
        SMALLINT_UNSIGNED sale_line_number
        INT_UNSIGNED receipt_id
        SMALLINT_UNSIGNED receipt_line_number
        BIGINT_UNSIGNED sale_return_id
        SMALLINT_UNSIGNED return_line_number
        BIGINT_UNSIGNED adjustment_id
        BIGINT_UNSIGNED production_batch_id
        SMALLINT_UNSIGNED production_input_line
        BIGINT_UNSIGNED production_output_id
    }
    store_operating_expense {
        SMALLINT_UNSIGNED store_id PK
        DATE expense_month PK
        ENUM__LABOR___PAYROLL_COST___BENEFITS___OCCUPANCY___UTILITIES___INSURANCE___MAINTENANCE___PROCESSING___EQUIPMENT___SUPPLIES___DEPRECIATION___LICENSES___OTHER__ expense_type PK
        DECIMAL_12_2_ full_store_budget
        DECIMAL_7_6_ allocation_rate
        DECIMAL_12_2_ allocated_amount
        VARCHAR_255_ assumption
    }
    store_region ||..o{ store : "fk_store_region"
    store ||..o{ employee : "fk_employee_store"
    job_role ||..o{ employee : "fk_employee_job_role"
    department o|..o{ employee : "fk_employee_department"
    employee o|..o{ employee : "fk_employee_manager"
    department ||..o{ category : "fk_category_department"
    brand ||..o{ product : "fk_product_brand"
    category ||..o{ product : "fk_product_category"
    product ||--o{ product_supplier : "fk_product_supplier_product"
    supplier ||--o{ product_supplier : "fk_product_supplier_supplier"
    store ||--o{ store_inventory : "fk_inventory_store"
    product ||--o{ store_inventory : "fk_inventory_product"
    customer ||..o| loyalty_account : "fk_loyalty_customer"
    store ||..o{ sale : "fk_sale_store"
    customer o|..o{ sale : "fk_sale_customer"
    employee ||..o{ sale : "fk_sale_employee"
    sale ||--o{ sale_item : "fk_sale_item_sale"
    product ||..o{ sale_item : "fk_sale_item_product"
    promotion ||--o{ product_promotion : "fk_product_promotion_promotion"
    product ||--o{ product_promotion : "fk_product_promotion_product"
    store_inventory ||..o{ inventory_adjustment : "fk_adjustment_inventory"
    employee ||..o{ inventory_adjustment : "fk_adjustment_employee"
    store ||..o{ purchase_order : "fk_purchase_order_store"
    supplier ||..o{ purchase_order : "fk_purchase_order_supplier"
    employee ||..o{ purchase_order : "fk_purchase_order_employee"
    purchase_order ||..o{ purchase_order_line : "fk_po_line_order_supplier"
    product_supplier ||..o{ purchase_order_line : "fk_po_line_product_supplier"
    purchase_order ||..o{ receipt : "fk_receipt_purchase_order"
    employee ||..o{ receipt : "fk_receipt_employee"
    receipt ||..o{ receipt_line : "fk_receipt_line_header"
    purchase_order_line ||..o{ receipt_line : "fk_receipt_line_order_line"
    sale ||--o{ sale_payment : "fk_sale_payment_sale"
    payment_method ||..o{ sale_payment : "fk_sale_payment_method"
    product ||--o{ product_price_history : "fk_price_history_product"
    loyalty_account ||..o{ loyalty_transaction : "fk_loyalty_transaction_account"
    sale o|..o{ loyalty_transaction : "fk_loyalty_transaction_sale"
    product_supplier ||--o{ product_supplier_cost_history : "fk_cost_history_product_supplier"
    store_inventory ||--o| inventory_opening : "fk_opening_inventory"
    sale ||..o{ sale_return : "fk_return_sale"
    employee ||..o{ sale_return : "fk_return_employee"
    sale_return ||..o{ sale_return_item : "fk_return_item_header"
    sale_item ||..o{ sale_return_item : "fk_return_item_original"
    sale_return ||..o{ sale_refund : "fk_refund_return"
    sale_payment ||..o{ sale_refund : "fk_refund_payment"
    store ||--o{ store_service_hours : "fk_service_store"
    store_inventory ||--o{ store_product_price_history : "fk_store_price_inventory"
    store ||--o{ store_supplier : "fk_store_supplier_store"
    supplier ||--o{ store_supplier : "fk_store_supplier_supplier"
    product ||..o| recipe : "fk_recipe_product"
    recipe ||--o{ recipe_ingredient : "fk_recipe_ingredient_recipe"
    product ||--o{ recipe_ingredient : "fk_recipe_ingredient_product"
    store ||..o{ production_batch : "fk_production_store"
    recipe ||..o{ production_batch : "fk_production_recipe"
    sale_item o|..o| production_batch : "fk_production_sale"
    production_batch ||--o{ production_input : "fk_input_batch"
    product ||..o{ production_input : "fk_input_product"
    production_batch ||--o{ prepared_food_allocation : "fk_allocation_batch"
    sale_item ||--o{ prepared_food_allocation : "fk_allocation_sale"
    production_batch ||--o{ production_disposal : "fk_disposal_batch"
    inventory_adjustment ||--o| production_disposal : "fk_disposal_adjustment"
    store ||--o{ daily_labor : "fk_labor_store"
    department ||--o{ daily_labor : "fk_labor_department"
    job_role ||--o{ daily_labor : "fk_labor_role"
    production_batch o|..o{ inventory_movement : "fk_movement_batch"
    production_input o|..o| inventory_movement : "fk_movement_input"
    store_inventory ||..o{ inventory_movement : "fk_movement_inventory"
    sale_item o|..o| inventory_movement : "fk_movement_sale"
    receipt_line o|..o| inventory_movement : "fk_movement_receipt"
    sale_return_item o|..o| inventory_movement : "fk_movement_return"
    inventory_adjustment o|..o| inventory_movement : "fk_movement_adjustment"
    store ||--o{ store_operating_expense : "fk_expense_store"
```

The 33 v2.0 entities remain. Eleven new entities add service calendars, store price history, supplier authorization, recipes/production/allocation/disposal, labor and edition metadata. Store keys 1 and 2 survive; keys 3–5 occur only in the archived v2.0 release.

Identifying relationships include sale/sale_item, receipt/receipt_line, production_batch/production_input and the associative composite keys. Generated production_output_id enforces one output posting. No negative inventory, expiry or cross-store production rules are silently delegated to a diagram: SQL audit coverage is in 05_validation_checks.sql.

Cardinality follows declared key/nullability rules: an optional parent endpoint allows NULL foreign keys; a zero-or-one child endpoint marks a unique relationship. Solid lines identify relationships whose foreign-key columns are part of the child primary key; dotted lines are non-identifying. Conditional business rules still require the documented CHECK constraints and audits.
