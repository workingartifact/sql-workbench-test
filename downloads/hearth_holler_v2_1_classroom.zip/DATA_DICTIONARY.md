# Hearth & Holler v2.1 data dictionary

AN/MKT 324. Authoritative schema: `01_create_schema.sql`. All money is USD DECIMAL. All timestamps are Lexington local DATETIME. Inventory units are retail packages or explicit internal recipe portions, never implicit fractional pounds. NULL sale.customer_id means anonymous checkout.

Closing snapshots (inventory, loyalty points, catalog prices, status) are distinct from dated events. Historical revenue/COGS uses `v_sales_activity`; sale status alone does not place a return in the correct reporting period. Composite context FKs deliberately repeat store, supplier or sale keys to prevent cross-context relationships. Ingredient/packaging costs are capitalized; all labor is expensed once.

## `store_region`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `region_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `region_id` | `TINYINT UNSIGNED` | PK | No | Surrogate region identifier. |
| `region_name` | `VARCHAR(60)` | UK | No | Unique public name of the region. |
| `regional_office_city` | `VARCHAR(60)` |  | No | City used as the region's administrative base. |
| `description` | `VARCHAR(255)` |  | Yes | Optional description of the trade area. |


```sql
region_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    region_name VARCHAR(60) NOT NULL UNIQUE,
    regional_office_city VARCHAR(60) NOT NULL,
    description VARCHAR(255) NULL
```

## `store`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `store_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK | No | Surrogate store identifier. |
| `region_id` | `TINYINT UNSIGNED` | FK | No | Region responsible for the store. |
| `store_number` | `CHAR(4)` | UK | No | Stable four-character operating number. |
| `store_name` | `VARCHAR(100)` |  | No | Customer-facing location name. |
| `street_address` | `VARCHAR(120)` |  | No | Fictional street address. |
| `city` | `VARCHAR(60)` |  | No | Store city. |
| `state_code` | `CHAR(2)` |  | No | Two-letter state code; defaults to KY. |
| `postal_code` | `CHAR(5)` |  | No | Five-character teaching postal code. |
| `phone` | `VARCHAR(20)` |  | No | Fictional store phone. |
| `opened_date` | `DATE` |  | No | Date the location opened. |
| `square_feet` | `INT UNSIGNED` |  | No | Approximate selling/building area for comparison. |
| `is_active` | `BOOLEAN` |  | No | Whether the store currently operates. |

- `fk_store_region`: (`region_id`) → `store_region` (`region_id`).

```sql
store_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    region_id TINYINT UNSIGNED NOT NULL,
    store_number CHAR(4) NOT NULL UNIQUE,
    store_name VARCHAR(100) NOT NULL,
    street_address VARCHAR(120) NOT NULL,
    city VARCHAR(60) NOT NULL,
    state_code CHAR(2) NOT NULL DEFAULT 'KY',
    postal_code CHAR(5) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    opened_date DATE NOT NULL,
    square_feet INT UNSIGNED NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_store_square_feet CHECK (square_feet BETWEEN 5000 AND 200000),
    CONSTRAINT fk_store_region FOREIGN KEY (region_id)
        REFERENCES store_region (region_id)
```

## `department`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `department_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `department_id` | `TINYINT UNSIGNED` | PK | No | Surrogate department identifier. |
| `department_name` | `VARCHAR(60)` | UK | No | Unique department name. |
| `description` | `VARCHAR(255)` |  | Yes | Optional statement of departmental scope. |


```sql
department_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(60) NOT NULL UNIQUE,
    description VARCHAR(255) NULL
```

## `job_role`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `job_role_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `job_role_id` | `TINYINT UNSIGNED` | PK | No | Surrogate role identifier. |
| `role_name` | `VARCHAR(60)` | UK | No | Unique job-role title. |
| `minimum_hourly_rate` | `DECIMAL(6,2)` |  | No | Bottom of the teaching pay band. |
| `maximum_hourly_rate` | `DECIMAL(6,2)` |  | No | Top of the teaching pay band. |
| `is_management` | `BOOLEAN` |  | No | Whether the role is managerial. |


```sql
job_role_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(60) NOT NULL UNIQUE,
    minimum_hourly_rate DECIMAL(6,2) NOT NULL,
    maximum_hourly_rate DECIMAL(6,2) NOT NULL,
    is_management BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT chk_job_role_rates CHECK (
        minimum_hourly_rate > 0 AND maximum_hourly_rate >= minimum_hourly_rate
    )
```

## `employee`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `employee_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `employee_id` | `INT UNSIGNED` | PK | No | Surrogate employee identifier. |
| `store_id` | `SMALLINT UNSIGNED` | FK | No | Employee's assigned store. |
| `job_role_id` | `TINYINT UNSIGNED` | FK | No | Employee's role. |
| `department_id` | `TINYINT UNSIGNED` | FK | Yes | Primary department; NULL for cross-department roles. |
| `manager_employee_id` | `INT UNSIGNED` | FK | Yes | Employee's manager in this same table; NULL at the top. |
| `first_name` | `VARCHAR(50)` |  | No | Fictional employee first name. |
| `last_name` | `VARCHAR(50)` |  | No | Fictional employee last name. |
| `hire_date` | `DATE` |  | No | Original hire date. |
| `hourly_rate` | `DECIMAL(6,2)` |  | No | Current teaching hourly pay rate. |
| `email` | `VARCHAR(120)` | UK | No | Unique fictional work email. |
| `employment_status` | `ENUM('ACTIVE', 'LEAVE', 'FORMER')` |  | No | Current workforce status. |

- `fk_employee_store`: (`store_id`) → `store` (`store_id`).
- `fk_employee_job_role`: (`job_role_id`) → `job_role` (`job_role_id`).
- `fk_employee_department`: (`department_id`) → `department` (`department_id`).
- `fk_employee_manager`: (`manager_employee_id`) → `employee` (`employee_id`).

```sql
employee_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    job_role_id TINYINT UNSIGNED NOT NULL,
    department_id TINYINT UNSIGNED NULL,
    manager_employee_id INT UNSIGNED NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    hire_date DATE NOT NULL,
    hourly_rate DECIMAL(6,2) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    employment_status ENUM('ACTIVE', 'LEAVE', 'FORMER') NOT NULL DEFAULT 'ACTIVE',
    CONSTRAINT chk_employee_rate CHECK (hourly_rate > 0),
    CONSTRAINT fk_employee_store FOREIGN KEY (store_id)
        REFERENCES store (store_id),
    CONSTRAINT fk_employee_job_role FOREIGN KEY (job_role_id)
        REFERENCES job_role (job_role_id),
    CONSTRAINT fk_employee_department FOREIGN KEY (department_id)
        REFERENCES department (department_id),
    CONSTRAINT fk_employee_manager FOREIGN KEY (manager_employee_id)
        REFERENCES employee (employee_id)
        ON DELETE SET NULL
```

## `category`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `category_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `category_id` | `TINYINT UNSIGNED` | PK | No | Surrogate category identifier. |
| `department_id` | `TINYINT UNSIGNED` | FK | No | Parent department. |
| `category_name` | `VARCHAR(60)` | UK | No | Unique category name. |
| `shelf_life_class` | `ENUM('PERISHABLE', 'SEMI_PERISHABLE', 'SHELF_STABLE')` |  | No | Broad handling/longevity class. |

- `fk_category_department`: (`department_id`) → `department` (`department_id`).

```sql
category_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_id TINYINT UNSIGNED NOT NULL,
    category_name VARCHAR(60) NOT NULL UNIQUE,
    shelf_life_class ENUM('PERISHABLE', 'SEMI_PERISHABLE', 'SHELF_STABLE') NOT NULL,
    CONSTRAINT fk_category_department FOREIGN KEY (department_id)
        REFERENCES department (department_id)
```

## `brand`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `brand_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `brand_id` | `SMALLINT UNSIGNED` | PK | No | Surrogate brand identifier. |
| `brand_name` | `VARCHAR(80)` | UK | No | Unique fictional brand name. |
| `brand_tagline` | `VARCHAR(160)` |  | Yes | Optional marketing tagline. |
| `home_city` | `VARCHAR(60)` |  | No | Fictional brand home city. |
| `home_state_code` | `CHAR(2)` |  | No | Brand home state code. |
| `is_store_brand` | `BOOLEAN` |  | No | Whether Hearth & Holler controls the label. |


```sql
brand_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    brand_name VARCHAR(80) NOT NULL UNIQUE,
    brand_tagline VARCHAR(160) NULL,
    home_city VARCHAR(60) NOT NULL,
    home_state_code CHAR(2) NOT NULL,
    is_store_brand BOOLEAN NOT NULL DEFAULT FALSE
```

## `product`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `product_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `product_id` | `INT UNSIGNED` | PK | No | Surrogate product identifier. |
| `brand_id` | `SMALLINT UNSIGNED` | FK | No | Product brand. |
| `category_id` | `TINYINT UNSIGNED` | FK | No | Product merchandise category. |
| `sku` | `VARCHAR(20)` | UK | No | Internal stock-keeping code. |
| `upc` | `CHAR(12)` | UK | No | Fictional unique retail barcode value. |
| `product_name` | `VARCHAR(120)` |  | No | Customer-facing item name. |
| `package_size` | `VARCHAR(40)` |  | No | Human-readable package declaration. |
| `unit_of_measure` | `ENUM('EACH', 'OUNCE', 'POUND', 'FLUID_OUNCE', 'COUNT')` |  | No | Primary package measure type. |
| `list_price` | `DECIMAL(8,2)` |  | No | Current standard retail price. |
| `unit_cost` | `DECIMAL(8,2)` |  | No | Catalog planning estimate; historical COGS is sale_item.cost_amount, never this current value. |
| `is_active` | `BOOLEAN` |  | No | Whether the product is currently active in the catalog. |
| `introduced_date` | `DATE` |  | No | Date the item entered the catalog. |
| `product_type` | `ENUM('RESALE','INGREDIENT','PACKAGING','PREPARED','BAR')` |  | No | RESALE, INGREDIENT, PACKAGING, PREPARED or BAR. Separate served beer and packaged retail SKUs. |
| `tax_rate` | `DECIMAL(5,4)` |  | No | Instructional SKU classification: qualifying grocery 0; prepared food, beer and taxable nonfood 0.06. |
| `is_sellable` | `BOOLEAN` |  | No | False for internal ingredient/packaging portions; these cannot appear in customer baskets. |
| `food_period` | `ENUM('ALL','BREAKFAST','LUNCH')` |  | No | ALL, BREAKFAST or LUNCH; demand/recipe scheduling classification. |

- `fk_product_brand`: (`brand_id`) → `brand` (`brand_id`).
- `fk_product_category`: (`category_id`) → `category` (`category_id`).

```sql
product_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    brand_id SMALLINT UNSIGNED NOT NULL,
    category_id TINYINT UNSIGNED NOT NULL,
    sku VARCHAR(20) NOT NULL UNIQUE,
    upc CHAR(12) NOT NULL UNIQUE,
    product_name VARCHAR(120) NOT NULL,
    package_size VARCHAR(40) NOT NULL,
    unit_of_measure ENUM('EACH', 'OUNCE', 'POUND', 'FLUID_OUNCE', 'COUNT') NOT NULL,
    list_price DECIMAL(8,2) NOT NULL,
    unit_cost DECIMAL(8,2) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    introduced_date DATE NOT NULL,
    product_type ENUM('RESALE','INGREDIENT','PACKAGING','PREPARED','BAR') NOT NULL DEFAULT 'RESALE',
    tax_rate DECIMAL(5,4) NOT NULL DEFAULT 0,
    is_sellable BOOLEAN NOT NULL DEFAULT TRUE,
    food_period ENUM('ALL','BREAKFAST','LUNCH') NOT NULL DEFAULT 'ALL',
    CONSTRAINT chk_product_tax CHECK (tax_rate IN (0,0.06)),
    CONSTRAINT uq_product_brand_name_size UNIQUE (brand_id, product_name, package_size),
    CONSTRAINT chk_product_prices CHECK (
        list_price >= 0 AND unit_cost >= 0 AND list_price >= unit_cost
    ),
    CONSTRAINT fk_product_brand FOREIGN KEY (brand_id)
        REFERENCES brand (brand_id),
    CONSTRAINT fk_product_category FOREIGN KEY (category_id)
        REFERENCES category (category_id)
```

## `supplier`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `supplier_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `supplier_id` | `SMALLINT UNSIGNED` | PK | No | Surrogate supplier identifier. |
| `supplier_name` | `VARCHAR(100)` | UK | No | Unique fictional supplier name. |
| `contact_name` | `VARCHAR(100)` |  | No | Fictional business contact. |
| `phone` | `VARCHAR(20)` |  | No | Fictional supplier phone. |
| `email` | `VARCHAR(120)` | UK | No | Unique fictional supplier email. |
| `city` | `VARCHAR(60)` |  | No | Supplier city. |
| `state_code` | `CHAR(2)` |  | No | Supplier state code. |
| `lead_time_days` | `TINYINT UNSIGNED` |  | No | Expected ordering lead time. |
| `supplier_rating` | `DECIMAL(3,2)` |  | No | Internal 1.00–5.00 performance rating. |
| `is_active` | `BOOLEAN` |  | No | Whether the supplier is approved for ordering. |


```sql
supplier_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL UNIQUE,
    contact_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    city VARCHAR(60) NOT NULL,
    state_code CHAR(2) NOT NULL,
    lead_time_days TINYINT UNSIGNED NOT NULL,
    supplier_rating DECIMAL(3,2) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_supplier_lead_time CHECK (lead_time_days BETWEEN 1 AND 60),
    CONSTRAINT chk_supplier_rating CHECK (supplier_rating BETWEEN 1.00 AND 5.00)
```

## `product_supplier`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `product_id, supplier_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `product_id` | `INT UNSIGNED` | PK/FK | No | Supplied product. |
| `supplier_id` | `SMALLINT UNSIGNED` | PK/FK | No | Supplier offering the product. |
| `supplier_product_code` | `VARCHAR(30)` |  | No | Supplier-specific ordering code; unique within supplier. |
| `wholesale_cost` | `DECIMAL(8,2)` |  | No | Current quoted supplier cost. |
| `is_primary_supplier` | `BOOLEAN` |  | No | Whether this is the preferred source. |
| `minimum_order_quantity` | `SMALLINT UNSIGNED` |  | No | Smallest case/unit order accepted. |

- `fk_product_supplier_product`: (`product_id`) → `product` (`product_id`).
- `fk_product_supplier_supplier`: (`supplier_id`) → `supplier` (`supplier_id`).

```sql
product_id INT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    supplier_product_code VARCHAR(30) NOT NULL,
    wholesale_cost DECIMAL(8,2) NOT NULL,
    is_primary_supplier BOOLEAN NOT NULL DEFAULT FALSE,
    minimum_order_quantity SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (product_id, supplier_id),
    UNIQUE (supplier_id, supplier_product_code),
    CONSTRAINT chk_product_supplier_cost CHECK (wholesale_cost >= 0),
    CONSTRAINT chk_product_supplier_moq CHECK (minimum_order_quantity > 0),
    CONSTRAINT fk_product_supplier_product FOREIGN KEY (product_id)
        REFERENCES product (product_id),
    CONSTRAINT fk_product_supplier_supplier FOREIGN KEY (supplier_id)
        REFERENCES supplier (supplier_id)
```

## `store_inventory`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `store_id, product_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Stocking store. |
| `product_id` | `INT UNSIGNED` | PK/FK | No | Stocked product. |
| `quantity_on_hand` | `INT UNSIGNED` |  | No | Closing physical units at dataset_metadata.reporting_end; opening plus all signed movements. |
| `inventory_value` | `DECIMAL(14,2)` |  | No | Closing USD moving-average inventory value, including recipe ingredient/packaging capitalization. |
| `reorder_point` | `INT UNSIGNED` |  | No | Balance at or below which replenishment is indicated. |
| `reorder_quantity` | `INT UNSIGNED` |  | No | Suggested replenishment quantity. |
| `shelf_location` | `VARCHAR(20)` |  | No | Simplified aisle/shelf locator. |
| `last_counted_at` | `DATETIME` |  | No | Fictional closing snapshot timestamp; not evidence of a real physical count. |

- `fk_inventory_store`: (`store_id`) → `store` (`store_id`).
- `fk_inventory_product`: (`product_id`) → `product` (`product_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    quantity_on_hand INT UNSIGNED NOT NULL DEFAULT 0,
    inventory_value DECIMAL(14,2) NOT NULL DEFAULT 0,
    CONSTRAINT chk_inventory_value CHECK (inventory_value >= 0),
    reorder_point INT UNSIGNED NOT NULL,
    reorder_quantity INT UNSIGNED NOT NULL,
    shelf_location VARCHAR(20) NOT NULL,
    last_counted_at DATETIME NOT NULL,
    PRIMARY KEY (store_id, product_id),
    CONSTRAINT chk_inventory_levels CHECK (
        reorder_quantity > 0 AND reorder_point >= 0
    ),
    CONSTRAINT fk_inventory_store FOREIGN KEY (store_id)
        REFERENCES store (store_id),
    CONSTRAINT fk_inventory_product FOREIGN KEY (product_id)
        REFERENCES product (product_id)
```

## `customer`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `customer_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `customer_id` | `INT UNSIGNED` | PK | No | Surrogate customer identifier. |
| `first_name` | `VARCHAR(50)` |  | No | Fictional first name. |
| `last_name` | `VARCHAR(50)` |  | No | Fictional last name. |
| `email` | `VARCHAR(120)` | UK | Yes | Optional unique fictional email. |
| `phone` | `VARCHAR(20)` |  | Yes | Optional fictional phone. |
| `city` | `VARCHAR(60)` |  | No | Customer city. |
| `state_code` | `CHAR(2)` |  | No | Customer state code. |
| `postal_code` | `CHAR(5)` |  | No | Teaching postal code. |
| `birth_year` | `YEAR` |  | Yes | Optional year for demographic exercises. |
| `created_at` | `DATETIME` |  | No | Customer-record creation time. |
| `marketing_opt_in` | `BOOLEAN` |  | No | Permission flag for marketing exercises. |


```sql
customer_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(120) NULL UNIQUE,
    phone VARCHAR(20) NULL,
    city VARCHAR(60) NOT NULL,
    state_code CHAR(2) NOT NULL DEFAULT 'KY',
    postal_code CHAR(5) NOT NULL,
    birth_year YEAR NULL,
    created_at DATETIME NOT NULL,
    marketing_opt_in BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT chk_customer_birth_year CHECK (birth_year IS NULL OR birth_year BETWEEN 1920 AND 2010)
```

## `loyalty_account`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `loyalty_account_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `loyalty_account_id` | `INT UNSIGNED` | PK | No | Surrogate loyalty-account identifier. |
| `customer_id` | `INT UNSIGNED` | FK/UK | No | Customer owner; uniqueness enforces at most one account. |
| `loyalty_number` | `CHAR(10)` | UK | No | Unique public-facing membership number. |
| `joined_date` | `DATE` |  | No | Membership start, no earlier than customer creation; 15 legacy dates repaired. |
| `points_balance` | `INT UNSIGNED` |  | No | Current unredeemed teaching points. |
| `tier` | `ENUM('SPROUT', 'SAPLING', 'MIGHTY_OAK')` |  | No | Current loyalty tier. |

- `fk_loyalty_customer`: (`customer_id`) → `customer` (`customer_id`).

```sql
loyalty_account_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL UNIQUE,
    loyalty_number CHAR(10) NOT NULL UNIQUE,
    joined_date DATE NOT NULL,
    points_balance INT UNSIGNED NOT NULL DEFAULT 0,
    tier ENUM('SPROUT', 'SAPLING', 'MIGHTY_OAK') NOT NULL DEFAULT 'SPROUT',
    CONSTRAINT fk_loyalty_customer FOREIGN KEY (customer_id)
        REFERENCES customer (customer_id)
```

## `payment_method`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `payment_method_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `payment_method_id` | `TINYINT UNSIGNED` | PK | No | Surrogate payment-method identifier. |
| `method_name` | `VARCHAR(40)` | UK | No | Unique tender label. |
| `processing_fee_rate` | `DECIMAL(5,4)` |  | No | Fractional processing fee estimate; 0.0225 means 2.25%. |


```sql
payment_method_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(40) NOT NULL UNIQUE,
    processing_fee_rate DECIMAL(5,4) NOT NULL DEFAULT 0,
    CONSTRAINT chk_payment_fee CHECK (processing_fee_rate BETWEEN 0 AND 0.1000)
```

## `sale`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `sale_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `sale_id` | `BIGINT UNSIGNED` | PK | No | Surrogate transaction identifier. |
| `store_id` | `SMALLINT UNSIGNED` | FK | No | Store recording the transaction. |
| `customer_id` | `INT UNSIGNED` | FK | Yes | Identified customer; NULL means anonymous checkout. |
| `employee_id` | `INT UNSIGNED` | FK | No | Employee associated with checkout. |
| `sold_at` | `DATETIME` |  | No | Transaction date and time. |
| `trading_date` | `DATE` |  | No | Lexington local retail day; service closing midnight belongs to the preceding trading interval. |
| `purchase_occasion` | `ENUM('BREAKFAST','LUNCH','TOP_UP','WEEKLY','DINNER','BAR')` |  | No | Fictional demand intent, not an assertion that every line belongs to that occasion. |
| `sale_status` | `ENUM('COMPLETED', 'RETURNED', 'VOIDED')` |  | No | Closing state: COMPLETED includes partial returns; RETURNED means all units returned; VOIDED never posted. |
| `subtotal` | `DECIMAL(10,2)` |  | No | Sum of extended line prices before discounts and tax. |
| `discount_total` | `DECIMAL(10,2)` |  | No | Sum of line-level discounts. |
| `tax_total` | `DECIMAL(10,2)` |  | No | Sum of SKU-specific line-rounded tax. Collected tax is not revenue. |
| `grand_total` | `DECIMAL(10,2)` |  | No | Original ticket including tax. Voids retain quoted amount but have no tender or stock postings. |

- `fk_sale_store`: (`store_id`) → `store` (`store_id`).
- `fk_sale_customer`: (`customer_id`) → `customer` (`customer_id`).
- `fk_sale_employee`: (`employee_id`) → `employee` (`employee_id`).

```sql
sale_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    customer_id INT UNSIGNED NULL,
    employee_id INT UNSIGNED NOT NULL,
    sold_at DATETIME NOT NULL,
    trading_date DATE NOT NULL,
    purchase_occasion ENUM('BREAKFAST','LUNCH','TOP_UP','WEEKLY','DINNER','BAR') NOT NULL,
    CONSTRAINT chk_sale_trading_date CHECK (DATE(sold_at) BETWEEN trading_date AND DATE_ADD(trading_date,INTERVAL 1 DAY)),
    sale_status ENUM('COMPLETED', 'RETURNED', 'VOIDED') NOT NULL DEFAULT 'COMPLETED',
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    tax_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    grand_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT chk_sale_totals CHECK (
        subtotal >= 0 AND discount_total >= 0 AND tax_total >= 0 AND grand_total >= 0
    ),
    INDEX idx_sale_sold_at (sold_at),
    INDEX idx_sale_store_date (store_id, sold_at),
    INDEX idx_sale_customer (customer_id),
    CONSTRAINT fk_sale_store FOREIGN KEY (store_id)
        REFERENCES store (store_id),
    CONSTRAINT fk_sale_customer FOREIGN KEY (customer_id)
        REFERENCES customer (customer_id)
        ON DELETE SET NULL,
    CONSTRAINT fk_sale_employee FOREIGN KEY (employee_id)
        REFERENCES employee (employee_id)
```

## `sale_item`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `sale_id, line_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `service_channel` | `ENUM('GROCERY','GRIDDLE','GRAB_GO','BAR')` |  | No | GROCERY, GRIDDLE, GRAB_GO or BAR. Mixed baskets retain each line channel. |
| `sale_id` | `BIGINT UNSIGNED` | PK/FK | No | Parent sale. |
| `line_number` | `SMALLINT UNSIGNED` | PK | No | Line sequence unique within the sale. |
| `product_id` | `INT UNSIGNED` | FK | No | Product sold. |
| `quantity` | `SMALLINT UNSIGNED` |  | No | Number of packages/units on the line. |
| `unit_price` | `DECIMAL(8,2)` |  | No | Historical price per unit at checkout. |
| `discount_amount` | `DECIMAL(8,2)` |  | No | Total discount applied to this line. |
| `tax_amount` | `DECIMAL(8,2)` |  | No | ROUND((quantity*unit_price-discount_amount)*product.tax_rate,2). |
| `cost_amount` | `DECIMAL(12,2)` |  | No | Total realized line COGS at store-product moving average immediately before issue; cents, zero for voids. |

- `fk_sale_item_sale`: (`sale_id`) → `sale` (`sale_id`).
- `fk_sale_item_product`: (`product_id`) → `product` (`product_id`).

```sql
service_channel ENUM('GROCERY','GRIDDLE','GRAB_GO','BAR') NOT NULL DEFAULT 'GROCERY',
    sale_id BIGINT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    unit_price DECIMAL(8,2) NOT NULL,
    discount_amount DECIMAL(8,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(8,2) NOT NULL,
    cost_amount DECIMAL(12,2) NOT NULL,
    CONSTRAINT chk_sale_item_financial CHECK (tax_amount >= 0 AND cost_amount >= 0),
    PRIMARY KEY (sale_id, line_number),
    CONSTRAINT uq_sale_product UNIQUE (sale_id, product_id),
    CONSTRAINT chk_sale_item_quantity CHECK (quantity > 0),
    CONSTRAINT chk_sale_item_amounts CHECK (
        unit_price >= 0 AND discount_amount >= 0
        AND discount_amount <= unit_price * quantity
    ),
    CONSTRAINT fk_sale_item_sale FOREIGN KEY (sale_id)
        REFERENCES sale (sale_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_sale_item_product FOREIGN KEY (product_id)
        REFERENCES product (product_id)
```

## `promotion`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `promotion_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `promotion_id` | `SMALLINT UNSIGNED` | PK | No | Surrogate promotion identifier. |
| `promotion_name` | `VARCHAR(100)` | UK | No | Unique offer name. |
| `promotion_description` | `VARCHAR(255)` |  | Yes | Optional offer explanation. |
| `start_date` | `DATE` |  | No | First eligible calendar date. |
| `end_date` | `DATE` |  | No | Last eligible calendar date. |
| `discount_type` | `ENUM('PERCENT', 'AMOUNT')` |  | No | Interpretation of `discount_value`. |
| `discount_value` | `DECIMAL(8,2)` |  | No | Percent value or fixed line-discount amount. |


```sql
promotion_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    promotion_name VARCHAR(100) NOT NULL UNIQUE,
    promotion_description VARCHAR(255) NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    discount_type ENUM('PERCENT', 'AMOUNT') NOT NULL,
    discount_value DECIMAL(8,2) NOT NULL,
    CONSTRAINT chk_promotion_dates CHECK (end_date >= start_date),
    CONSTRAINT chk_promotion_value CHECK (
        discount_value > 0
        AND (discount_type = 'AMOUNT' OR discount_value <= 100)
    )
```

## `product_promotion`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `promotion_id, product_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `promotion_id` | `SMALLINT UNSIGNED` | PK/FK | No | Participating promotion. |
| `product_id` | `INT UNSIGNED` | PK/FK | No | Participating product. |
| `featured_display` | `BOOLEAN` |  | No | Whether the item received special display placement. |

- `fk_product_promotion_promotion`: (`promotion_id`) → `promotion` (`promotion_id`).
- `fk_product_promotion_product`: (`product_id`) → `product` (`product_id`).

```sql
promotion_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    featured_display BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (promotion_id, product_id),
    CONSTRAINT fk_product_promotion_promotion FOREIGN KEY (promotion_id)
        REFERENCES promotion (promotion_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_product_promotion_product FOREIGN KEY (product_id)
        REFERENCES product (product_id)
```

## `inventory_adjustment`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `adjustment_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `adjustment_id` | `BIGINT UNSIGNED` | PK | No | Surrogate adjustment-event identifier. |
| `store_id` | `SMALLINT UNSIGNED` | FK | No | Store half of the referenced inventory row. |
| `product_id` | `INT UNSIGNED` | FK | No | Product half of the referenced inventory row. |
| `employee_id` | `INT UNSIGNED` | FK | No | Employee who recorded the event. |
| `adjusted_at` | `DATETIME` |  | No | Event timestamp. |
| `quantity_change` | `SMALLINT` |  | No | Signed increase or decrease; zero is prohibited. |
| `reason` | `ENUM('DELIVERY', 'DAMAGE', 'SPOILAGE', 'COUNT_CORRECTION', 'DONATION')` |  | No | Loss/correction reason. DELIVERY retained for compatibility but never used in v2; receipts post independently. |
| `notes` | `VARCHAR(255)` |  | Yes | Optional explanatory note. |

- `fk_adjustment_inventory`: (`store_id, product_id`) → `store_inventory` (`store_id, product_id`).
- `fk_adjustment_employee`: (`employee_id`) → `employee` (`employee_id`).

```sql
adjustment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    employee_id INT UNSIGNED NOT NULL,
    adjusted_at DATETIME NOT NULL,
    quantity_change SMALLINT NOT NULL,
    reason ENUM('DELIVERY', 'DAMAGE', 'SPOILAGE', 'COUNT_CORRECTION', 'DONATION') NOT NULL,
    notes VARCHAR(255) NULL,
    CONSTRAINT chk_adjustment_nonzero CHECK (quantity_change <> 0),
    CONSTRAINT fk_adjustment_inventory FOREIGN KEY (store_id, product_id)
        REFERENCES store_inventory (store_id, product_id),
    CONSTRAINT fk_adjustment_employee FOREIGN KEY (employee_id)
        REFERENCES employee (employee_id)
```

## `purchase_order`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `purchase_order_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `purchase_order_id` | `INT UNSIGNED` | PK | No | Auto-increment order identifier. |
| `store_id` | `SMALLINT UNSIGNED` | FK | No | Store issuing the order. |
| `supplier_id` | `SMALLINT UNSIGNED` | FK | No | Only supplier authorized for this order. |
| `ordered_by_employee_id` | `INT UNSIGNED` | FK | No | Ordering employee; same-store assignment is audited separately. |
| `ordered_at` | `DATETIME` |  | No | Order placement timestamp. |
| `expected_delivery_date` | `DATE` |  | No | Promised delivery date; cannot precede order date. |
| `purchase_order_status` | `ENUM('OPEN', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED')` |  | No | Current fulfillment state, reconciled against receipt quantities. |

- `fk_purchase_order_store`: (`store_id`) → `store` (`store_id`).
- `fk_purchase_order_supplier`: (`supplier_id`) → `supplier` (`supplier_id`).
- `fk_purchase_order_employee`: (`ordered_by_employee_id`) → `employee` (`employee_id`).

```sql
purchase_order_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    ordered_by_employee_id INT UNSIGNED NOT NULL,
    ordered_at DATETIME NOT NULL,
    expected_delivery_date DATE NOT NULL,
    purchase_order_status ENUM('OPEN', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED') NOT NULL,
    CONSTRAINT uq_purchase_order_supplier UNIQUE (purchase_order_id, supplier_id),
    CONSTRAINT chk_purchase_order_dates CHECK (expected_delivery_date >= DATE(ordered_at)),
    INDEX idx_purchase_order_date (ordered_at),
    CONSTRAINT fk_purchase_order_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_purchase_order_supplier FOREIGN KEY (supplier_id) REFERENCES supplier (supplier_id),
    CONSTRAINT fk_purchase_order_employee FOREIGN KEY (ordered_by_employee_id) REFERENCES employee (employee_id)
```

## `purchase_order_line`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `purchase_order_id, line_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `purchase_order_id` | `INT UNSIGNED` | PK/FK | No | Order half of the enforced order/supplier reference. |
| `line_number` | `SMALLINT UNSIGNED` | PK | No | Positive sequence within this PO. |
| `product_id` | `INT UNSIGNED` | FK | No | Product from the supplier's eligible catalog. |
| `supplier_id` | `SMALLINT UNSIGNED` | FK | No | Must match both the order supplier and product_supplier. |
| `quantity_ordered` | `SMALLINT UNSIGNED` |  | No | Positive number of sellable packages ordered. |
| `unit_cost` | `DECIMAL(8,2)` |  | No | Historical agreed procurement cost per package. |

- `fk_po_line_order_supplier`: (`purchase_order_id, supplier_id`) → `purchase_order` (`purchase_order_id, supplier_id`).
- `fk_po_line_product_supplier`: (`product_id, supplier_id`) → `product_supplier` (`product_id, supplier_id`).

```sql
purchase_order_id INT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    quantity_ordered SMALLINT UNSIGNED NOT NULL,
    unit_cost DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (purchase_order_id, line_number),
    CONSTRAINT uq_purchase_order_product UNIQUE (purchase_order_id, product_id),
    CONSTRAINT chk_purchase_order_line CHECK (line_number > 0 AND quantity_ordered > 0 AND unit_cost >= 0),
    CONSTRAINT fk_po_line_order_supplier FOREIGN KEY (purchase_order_id, supplier_id)
        REFERENCES purchase_order (purchase_order_id, supplier_id),
    CONSTRAINT fk_po_line_product_supplier FOREIGN KEY (product_id, supplier_id)
        REFERENCES product_supplier (product_id, supplier_id)
```

## `receipt`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `receipt_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `receipt_id` | `INT UNSIGNED` | PK | No | Auto-increment delivery identifier. |
| `purchase_order_id` | `INT UNSIGNED` | FK | No | Order being fulfilled. |
| `received_by_employee_id` | `INT UNSIGNED` | FK | No | Employee accepting delivery; store assignment audited separately. |
| `received_at` | `DATETIME` |  | No | Actual arrival timestamp. |
| `delivery_reference` | `VARCHAR(40)` |  | No | Fictional supplier delivery reference, unique within its PO. |

- `fk_receipt_purchase_order`: (`purchase_order_id`) → `purchase_order` (`purchase_order_id`).
- `fk_receipt_employee`: (`received_by_employee_id`) → `employee` (`employee_id`).

```sql
receipt_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    purchase_order_id INT UNSIGNED NOT NULL,
    received_by_employee_id INT UNSIGNED NOT NULL,
    received_at DATETIME NOT NULL,
    delivery_reference VARCHAR(40) NOT NULL,
    CONSTRAINT uq_receipt_order UNIQUE (receipt_id, purchase_order_id),
    CONSTRAINT uq_receipt_reference UNIQUE (purchase_order_id, delivery_reference),
    INDEX idx_receipt_date (received_at),
    CONSTRAINT fk_receipt_purchase_order FOREIGN KEY (purchase_order_id) REFERENCES purchase_order (purchase_order_id),
    CONSTRAINT fk_receipt_employee FOREIGN KEY (received_by_employee_id) REFERENCES employee (employee_id)
```

## `receipt_line`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `receipt_id, line_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `receipt_id` | `INT UNSIGNED` | PK/FK | No | Receipt half of enforced receipt/order reference. |
| `line_number` | `SMALLINT UNSIGNED` | PK | No | Positive sequence within this receipt; need not equal the PO line number. |
| `purchase_order_id` | `INT UNSIGNED` | FK | No | Must match both receipt header and fulfilled PO line. |
| `purchase_order_line_number` | `SMALLINT UNSIGNED` | FK | No | Line number of the PO commitment being fulfilled. |
| `quantity_received` | `SMALLINT UNSIGNED` |  | No | Positive packages accepted on this delivery. |

- `fk_receipt_line_header`: (`receipt_id, purchase_order_id`) → `receipt` (`receipt_id, purchase_order_id`).
- `fk_receipt_line_order_line`: (`purchase_order_id, purchase_order_line_number`) → `purchase_order_line` (`purchase_order_id, line_number`).

```sql
receipt_id INT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    purchase_order_id INT UNSIGNED NOT NULL,
    purchase_order_line_number SMALLINT UNSIGNED NOT NULL,
    quantity_received SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (receipt_id, line_number),
    CONSTRAINT uq_receipt_po_line UNIQUE (receipt_id, purchase_order_id, purchase_order_line_number),
    CONSTRAINT chk_receipt_line CHECK (line_number > 0 AND quantity_received > 0),
    CONSTRAINT fk_receipt_line_header FOREIGN KEY (receipt_id, purchase_order_id)
        REFERENCES receipt (receipt_id, purchase_order_id),
    CONSTRAINT fk_receipt_line_order_line FOREIGN KEY (purchase_order_id, purchase_order_line_number)
        REFERENCES purchase_order_line (purchase_order_id, line_number)
```

## `sale_payment`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `sale_id, payment_sequence`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `sale_id` | `BIGINT UNSIGNED` | PK/FK | No | Sale whose original ticket is tendered. |
| `payment_sequence` | `SMALLINT UNSIGNED` | PK | No | Positive tender sequence within the sale. |
| `payment_method_id` | `TINYINT UNSIGNED` | FK | No | Method used for this portion; moved out of sale. |
| `amount` | `DECIMAL(10,2)` |  | No | Positive original posted tender including tax; no rows for voids. Refunds are separate. |

- `fk_sale_payment_sale`: (`sale_id`) → `sale` (`sale_id`).
- `fk_sale_payment_method`: (`payment_method_id`) → `payment_method` (`payment_method_id`).

```sql
sale_id BIGINT UNSIGNED NOT NULL,
    payment_sequence SMALLINT UNSIGNED NOT NULL,
    payment_method_id TINYINT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (sale_id, payment_sequence),
    CONSTRAINT chk_sale_payment CHECK (payment_sequence > 0 AND amount > 0),
    CONSTRAINT fk_sale_payment_sale FOREIGN KEY (sale_id) REFERENCES sale (sale_id) ON DELETE CASCADE,
    CONSTRAINT fk_sale_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_method (payment_method_id)
```

## `product_price_history`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `product_id, effective_start_date`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `product_id` | `INT UNSIGNED` | PK/FK | No | Product whose standard price is recorded. |
| `effective_start_date` | `DATE` | PK | No | Inclusive start date. Latest applicable start determines the price. |
| `list_price` | `DECIMAL(8,2)` |  | No | Nonnegative standard price per package for this period. |

- `fk_price_history_product`: (`product_id`) → `product` (`product_id`).

```sql
product_id INT UNSIGNED NOT NULL,
    effective_start_date DATE NOT NULL,
    list_price DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (product_id, effective_start_date),
    CONSTRAINT chk_price_history CHECK (list_price >= 0),
    CONSTRAINT fk_price_history_product FOREIGN KEY (product_id) REFERENCES product (product_id)
```

## `loyalty_transaction`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `loyalty_transaction_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `loyalty_transaction_id` | `INT UNSIGNED` | PK | No | Auto-increment event identifier; timestamp ties ordered by this ID. |
| `loyalty_account_id` | `INT UNSIGNED` | FK | No | Account whose points change. |
| `sale_id` | `BIGINT UNSIGNED` | FK | Yes | Related sale, if any; ownership and status audited separately. |
| `transacted_at` | `DATETIME` |  | No | Event timestamp. |
| `transaction_type` | `ENUM('EARN', 'REDEEM', 'ADJUST', 'EXPIRE')` |  | No | Earn is positive; redeem/expire negative; adjustment either sign. |
| `points_change` | `INT` |  | No | Signed nonzero number of points added or deducted. |
| `notes` | `VARCHAR(255)` |  | Yes | Explains opening/welcome award, one point per whole net dollar, noncash rewards, or return reversal. |

- `fk_loyalty_transaction_account`: (`loyalty_account_id`) → `loyalty_account` (`loyalty_account_id`).
- `fk_loyalty_transaction_sale`: (`sale_id`) → `sale` (`sale_id`).

```sql
loyalty_transaction_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loyalty_account_id INT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NULL,
    transacted_at DATETIME NOT NULL,
    transaction_type ENUM('EARN', 'REDEEM', 'ADJUST', 'EXPIRE') NOT NULL,
    points_change INT NOT NULL,
    notes VARCHAR(255) NULL,
    CONSTRAINT chk_loyalty_points CHECK (
        points_change <> 0 AND (
            (transaction_type = 'EARN' AND points_change > 0)
            OR (transaction_type IN ('REDEEM', 'EXPIRE') AND points_change < 0)
            OR transaction_type = 'ADJUST'
        )
    ),
    INDEX idx_loyalty_transaction_date (loyalty_account_id, transacted_at, loyalty_transaction_id),
    CONSTRAINT fk_loyalty_transaction_account FOREIGN KEY (loyalty_account_id) REFERENCES loyalty_account (loyalty_account_id),
    CONSTRAINT fk_loyalty_transaction_sale FOREIGN KEY (sale_id) REFERENCES sale (sale_id)
```

## `product_supplier_cost_history`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `product_id, supplier_id, effective_start_date`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `product_id` | `INT UNSIGNED` | PK/FK | No | Product half of the sourcing relationship. |
| `supplier_id` | `SMALLINT UNSIGNED` | PK/FK | No | Supplier half of the sourcing relationship. |
| `effective_start_date` | `DATE` | PK | No | Inclusive date the quote takes effect, until the next start. |
| `wholesale_cost` | `DECIMAL(8,2)` |  | No | Nonnegative supplier quote per sellable package. |

- `fk_cost_history_product_supplier`: (`product_id, supplier_id`) → `product_supplier` (`product_id, supplier_id`).

```sql
product_id INT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    effective_start_date DATE NOT NULL,
    wholesale_cost DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (product_id, supplier_id, effective_start_date),
    CONSTRAINT chk_supplier_cost_history CHECK (wholesale_cost >= 0),
    CONSTRAINT fk_cost_history_product_supplier FOREIGN KEY (product_id, supplier_id)
        REFERENCES product_supplier (product_id, supplier_id)
```

## `inventory_opening`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `store_id, product_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Store half of inventory key. |
| `product_id` | `INT UNSIGNED` | PK/FK | No | Product half of inventory key. |
| `opened_at` | `DATETIME` |  | No | Opening instant: December 31, 2024 23:59:59. Earlier stock acquisition is outside retained history. |
| `quantity` | `INT UNSIGNED` |  | No | Opening retail packages or internal ingredient/packaging portions; units follow product.package_size. |
| `inventory_value` | `DECIMAL(14,2)` |  | No | Opening total cost in USD; quantity times opening effective primary-supplier quote, an explicit valuation assumption. |

- `fk_opening_inventory`: (`store_id, product_id`) → `store_inventory` (`store_id, product_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    opened_at DATETIME NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    inventory_value DECIMAL(14,2) NOT NULL,
    PRIMARY KEY (store_id, product_id),
    CONSTRAINT chk_opening_value CHECK (inventory_value >= 0 AND (quantity > 0 OR inventory_value = 0)),
    CONSTRAINT fk_opening_inventory FOREIGN KEY (store_id, product_id)
        REFERENCES store_inventory (store_id, product_id)
```

## `sale_return`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `sale_return_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `sale_return_id` | `BIGINT UNSIGNED` | PK | No | Return-event identifier. |
| `sale_id` | `BIGINT UNSIGNED` | FK | No | Original posted ticket; multiple returns are structurally possible. |
| `employee_id` | `INT UNSIGNED` | FK | No | Employee handling return at original store. |
| `returned_at` | `DATETIME` |  | No | Recognition timestamp for revenue/tax/COGS reversal and refund. |
| `reason` | `VARCHAR(100)` |  | No | Fictional return explanation. |
| `net_amount` | `DECIMAL(10,2)` |  | No | Positive merchandise refund excluding tax. |
| `tax_amount` | `DECIMAL(10,2)` |  | No | Positive tax reversed. |
| `refund_total` | `DECIMAL(10,2)` |  | No | Net amount plus tax; must equal refund portions. |

- `fk_return_sale`: (`sale_id`) → `sale` (`sale_id`).
- `fk_return_employee`: (`employee_id`) → `employee` (`employee_id`).

```sql
sale_return_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sale_id BIGINT UNSIGNED NOT NULL,
    employee_id INT UNSIGNED NOT NULL,
    returned_at DATETIME NOT NULL,
    reason VARCHAR(100) NOT NULL,
    net_amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL,
    refund_total DECIMAL(10,2) NOT NULL,
    CONSTRAINT uq_return_sale UNIQUE (sale_return_id, sale_id),
    CONSTRAINT chk_return_total CHECK (net_amount > 0 AND tax_amount >= 0 AND refund_total = net_amount + tax_amount),
    CONSTRAINT fk_return_sale FOREIGN KEY (sale_id) REFERENCES sale (sale_id),
    CONSTRAINT fk_return_employee FOREIGN KEY (employee_id) REFERENCES employee (employee_id),
    INDEX idx_return_date (returned_at)
```

## `sale_return_item`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `sale_return_id, line_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `sale_return_id` | `BIGINT UNSIGNED` | PK/FK | No | Identifying return header. |
| `line_number` | `SMALLINT UNSIGNED` | PK | No | Positive line sequence within return. |
| `sale_id` | `BIGINT UNSIGNED` | FK | No | Controlled redundancy constrained to return header and original sale line. |
| `sale_line_number` | `SMALLINT UNSIGNED` | FK | No | Original checkout line number. |
| `quantity` | `SMALLINT UNSIGNED` |  | No | Units returned; cumulative returns cannot exceed original units (audit). |
| `net_amount` | `DECIMAL(10,2)` |  | No | Positive original discounted line value returned. Seed returns whole lines; no partial-unit rounding ambiguity. |
| `tax_amount` | `DECIMAL(10,2)` |  | No | Original line tax reversed. |
| `cost_amount` | `DECIMAL(12,2)` |  | No | Original realized line cost reversed; independent of current quote or current average. |

- `fk_return_item_header`: (`sale_return_id, sale_id`) → `sale_return` (`sale_return_id, sale_id`).
- `fk_return_item_original`: (`sale_id, sale_line_number`) → `sale_item` (`sale_id, line_number`).

```sql
sale_return_id BIGINT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NOT NULL,
    sale_line_number SMALLINT UNSIGNED NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    net_amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL,
    cost_amount DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (sale_return_id, line_number),
    CONSTRAINT uq_return_original_line UNIQUE (sale_return_id, sale_id, sale_line_number),
    CONSTRAINT chk_return_item CHECK (line_number > 0 AND quantity > 0 AND net_amount > 0 AND tax_amount >= 0 AND cost_amount >= 0),
    CONSTRAINT fk_return_item_header FOREIGN KEY (sale_return_id, sale_id) REFERENCES sale_return (sale_return_id, sale_id),
    CONSTRAINT fk_return_item_original FOREIGN KEY (sale_id, sale_line_number) REFERENCES sale_item (sale_id, line_number)
```

## `sale_refund`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `sale_return_id, refund_sequence`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `sale_return_id` | `BIGINT UNSIGNED` | PK/FK | No | Identifying return event. |
| `refund_sequence` | `SMALLINT UNSIGNED` | PK | No | Positive tender-refund portion number. |
| `sale_id` | `BIGINT UNSIGNED` | FK | No | Constrained sale context for return and original tender. |
| `payment_sequence` | `SMALLINT UNSIGNED` | FK | No | Original payment portion being refunded. |
| `refunded_at` | `DATETIME` |  | No | Refund timestamp, at or after return. |
| `amount` | `DECIMAL(10,2)` |  | No | Positive amount refunded to original tender; cumulative refund cannot exceed that tender. |

- `fk_refund_return`: (`sale_return_id, sale_id`) → `sale_return` (`sale_return_id, sale_id`).
- `fk_refund_payment`: (`sale_id, payment_sequence`) → `sale_payment` (`sale_id, payment_sequence`).

```sql
sale_return_id BIGINT UNSIGNED NOT NULL,
    refund_sequence SMALLINT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NOT NULL,
    payment_sequence SMALLINT UNSIGNED NOT NULL,
    refunded_at DATETIME NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (sale_return_id, refund_sequence),
    CONSTRAINT chk_refund_amount CHECK (refund_sequence > 0 AND amount > 0),
    CONSTRAINT fk_refund_return FOREIGN KEY (sale_return_id, sale_id) REFERENCES sale_return (sale_return_id, sale_id),
    CONSTRAINT fk_refund_payment FOREIGN KEY (sale_id, payment_sequence) REFERENCES sale_payment (sale_id, payment_sequence)
```

## `store_service_hours`

Weekly retail and department service calendars; independent alcohol permissions are hypothetical.

Primary key: `store_id,service,weekday_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Store id. See table purpose and constraints for operational context. |
| `service` | `ENUM('RETAIL','GRIDDLE','KITCHEN','BAR','PACKAGE_BEER')` | PK | No | Service. See table purpose and constraints for operational context. |
| `weekday_number` | `TINYINT UNSIGNED` | PK | No | MySQL WEEKDAY: Monday=0 through Sunday=6. |
| `opens_at` | `TIME` |  | No | Opens at. See table purpose and constraints for operational context. |
| `closes_at` | `TIME` |  | No | Closes at. See table purpose and constraints for operational context. |
| `close_day_offset` | `TINYINT UNSIGNED` |  | No | 0 same day; 1 next-day midnight. Service intervals are half-open [open,close). |

- `fk_service_store`: (`store_id`) → `store` (`store_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    service ENUM('RETAIL','GRIDDLE','KITCHEN','BAR','PACKAGE_BEER') NOT NULL,
    weekday_number TINYINT UNSIGNED NOT NULL,
    opens_at TIME NOT NULL,
    closes_at TIME NOT NULL,
    close_day_offset TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (store_id,service,weekday_number),
    CONSTRAINT chk_service_hours CHECK (weekday_number BETWEEN 0 AND 6 AND close_day_offset IN (0,1)
      AND TIME_TO_SEC(opens_at)>=0 AND TIME_TO_SEC(opens_at)<86400
      AND TIME_TO_SEC(closes_at)>=0 AND TIME_TO_SEC(closes_at)<86400
      AND TIME_TO_SEC(closes_at)+close_day_offset*86400>TIME_TO_SEC(opens_at)),
    CONSTRAINT fk_service_store FOREIGN KEY (store_id) REFERENCES store (store_id)
```

## `store_product_price_history`

Dated store-level selling prices. Actual sold prices remain immutable sale-line facts.

Primary key: `store_id,product_id,effective_start_date`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Store id. See table purpose and constraints for operational context. |
| `product_id` | `INT UNSIGNED` | PK/FK | No | Product id. See table purpose and constraints for operational context. |
| `effective_start_date` | `DATE` | PK | No | Effective start date. See table purpose and constraints for operational context. |
| `list_price` | `DECIMAL(8,2)` |  | No | List price. See table purpose and constraints for operational context. |

- `fk_store_price_inventory`: (`store_id,product_id`) → `store_inventory` (`store_id,product_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    effective_start_date DATE NOT NULL,
    list_price DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (store_id,product_id,effective_start_date),
    CONSTRAINT chk_store_price CHECK (list_price>=0),
    CONSTRAINT fk_store_price_inventory FOREIGN KEY (store_id,product_id) REFERENCES store_inventory (store_id,product_id)
```

## `store_supplier`

Authorized store/supplier associative entity; purchasing must honor it.

Primary key: `store_id,supplier_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Store id. See table purpose and constraints for operational context. |
| `supplier_id` | `SMALLINT UNSIGNED` | PK/FK | No | Supplier id. See table purpose and constraints for operational context. |
| `delivery_days` | `TINYINT UNSIGNED` |  | No | Seven-day delivery-service assumption; not a weekday bitmask. Catalog lead time determines due date. |

- `fk_store_supplier_store`: (`store_id`) → `store` (`store_id`).
- `fk_store_supplier_supplier`: (`supplier_id`) → `supplier` (`supplier_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    delivery_days TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (store_id,supplier_id),
    CONSTRAINT chk_delivery_days CHECK (delivery_days BETWEEN 1 AND 7),
    CONSTRAINT fk_store_supplier_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_store_supplier_supplier FOREIGN KEY (supplier_id) REFERENCES supplier (supplier_id)
```

## `recipe`

One recipe per prepared product. Labor minutes are analytical, not inventory cost.

Primary key: `recipe_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `recipe_id` | `INT UNSIGNED` | PK | No | Recipe id. See table purpose and constraints for operational context. |
| `product_id` | `INT UNSIGNED` | FK/UK | No | Product id. See table purpose and constraints for operational context. |
| `recipe_name` | `VARCHAR(100)` |  | No | Recipe name. See table purpose and constraints for operational context. |
| `preparation_minutes` | `DECIMAL(6,2)` |  | No | Preparation minutes. See table purpose and constraints for operational context. |
| `shelf_life_hours` | `SMALLINT UNSIGNED` |  | No | Shelf life hours. See table purpose and constraints for operational context. |

- `fk_recipe_product`: (`product_id`) → `product` (`product_id`).

```sql
recipe_id INT UNSIGNED NOT NULL PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL UNIQUE,
    recipe_name VARCHAR(100) NOT NULL,
    preparation_minutes DECIMAL(6,2) NOT NULL,
    shelf_life_hours SMALLINT UNSIGNED NOT NULL,
    CONSTRAINT chk_recipe CHECK (preparation_minutes>0 AND shelf_life_hours BETWEEN 1 AND 72),
    CONSTRAINT fk_recipe_product FOREIGN KEY (product_id) REFERENCES product (product_id)
```

## `recipe_ingredient`

Recipe/ingredient associative entity. Integer quantities denote declared portion units, including packaging.

Primary key: `recipe_id,ingredient_product_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `recipe_id` | `INT UNSIGNED` | PK/FK | No | Recipe id. See table purpose and constraints for operational context. |
| `ingredient_product_id` | `INT UNSIGNED` | PK/FK | No | Ingredient product id. See table purpose and constraints for operational context. |
| `quantity_per_unit` | `SMALLINT UNSIGNED` |  | No | Quantity per unit. See table purpose and constraints for operational context. |

- `fk_recipe_ingredient_recipe`: (`recipe_id`) → `recipe` (`recipe_id`).
- `fk_recipe_ingredient_product`: (`ingredient_product_id`) → `product` (`product_id`).

```sql
recipe_id INT UNSIGNED NOT NULL,
    ingredient_product_id INT UNSIGNED NOT NULL,
    quantity_per_unit SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (recipe_id,ingredient_product_id),
    CONSTRAINT chk_recipe_quantity CHECK (quantity_per_unit>0),
    CONSTRAINT fk_recipe_ingredient_recipe FOREIGN KEY (recipe_id) REFERENCES recipe (recipe_id),
    CONSTRAINT fk_recipe_ingredient_product FOREIGN KEY (ingredient_product_id) REFERENCES product (product_id)
```

## `production_batch`

Downtown made-to-order batches identify their sale line; South scheduled batches precede sales.

Primary key: `production_batch_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `production_batch_id` | `BIGINT UNSIGNED` | PK | No | Production batch id. See table purpose and constraints for operational context. |
| `store_id` | `SMALLINT UNSIGNED` | FK | No | Store id. See table purpose and constraints for operational context. |
| `recipe_id` | `INT UNSIGNED` | FK | No | Recipe id. See table purpose and constraints for operational context. |
| `production_method` | `ENUM('MADE_TO_ORDER','BATCH')` |  | No | Production method. See table purpose and constraints for operational context. |
| `scheduled_at` | `DATETIME` |  | No | Scheduled at. See table purpose and constraints for operational context. |
| `started_at` | `DATETIME` |  | No | Started at. See table purpose and constraints for operational context. |
| `completed_at` | `DATETIME` |  | No | Completed at. See table purpose and constraints for operational context. |
| `available_at` | `DATETIME` |  | No | Finished units available no earlier than completion; sales allocations must be at/after this instant. |
| `expires_at` | `DATETIME` |  | No | Completion plus recipe shelf life. No sale at or after expiration. |
| `quantity_produced` | `INT UNSIGNED` |  | No | Quantity produced. See table purpose and constraints for operational context. |
| `ingredient_cost` | `DECIMAL(12,2)` |  | No | Sum of non-packaging input moving-average costs at production. |
| `packaging_cost` | `DECIMAL(12,2)` |  | No | Sum of packaging input moving-average costs at production. |
| `labor_minutes` | `DECIMAL(10,2)` |  | No | Recipe preparation-time memo; not capitalized and not an additional expense posting. |
| `sale_id` | `BIGINT UNSIGNED` | FK | Yes | Sale id. See table purpose and constraints for operational context. |
| `sale_line_number` | `SMALLINT UNSIGNED` | FK | Yes | Sale line number. See table purpose and constraints for operational context. |

- `fk_production_store`: (`store_id`) → `store` (`store_id`).
- `fk_production_recipe`: (`recipe_id`) → `recipe` (`recipe_id`).
- `fk_production_sale`: (`sale_id,sale_line_number`) → `sale_item` (`sale_id,line_number`).

```sql
production_batch_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    recipe_id INT UNSIGNED NOT NULL,
    production_method ENUM('MADE_TO_ORDER','BATCH') NOT NULL,
    scheduled_at DATETIME NOT NULL,
    started_at DATETIME NOT NULL,
    completed_at DATETIME NOT NULL,
    available_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    quantity_produced INT UNSIGNED NOT NULL,
    ingredient_cost DECIMAL(12,2) NOT NULL,
    packaging_cost DECIMAL(12,2) NOT NULL,
    labor_minutes DECIMAL(10,2) NOT NULL,
    sale_id BIGINT UNSIGNED NULL,
    sale_line_number SMALLINT UNSIGNED NULL,
    CONSTRAINT uq_production_sale UNIQUE (sale_id,sale_line_number),
    CONSTRAINT chk_production CHECK (quantity_produced>0 AND ingredient_cost>=0 AND packaging_cost>=0 AND labor_minutes>0
      AND scheduled_at<=started_at AND started_at<=completed_at AND completed_at<=available_at AND available_at<expires_at
      AND ((production_method='MADE_TO_ORDER' AND store_id=1 AND sale_id IS NOT NULL AND sale_line_number IS NOT NULL)
        OR (production_method='BATCH' AND store_id=2 AND sale_id IS NULL AND sale_line_number IS NULL))),
    CONSTRAINT fk_production_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_production_recipe FOREIGN KEY (recipe_id) REFERENCES recipe (recipe_id),
    CONSTRAINT fk_production_sale FOREIGN KEY (sale_id,sale_line_number) REFERENCES sale_item (sale_id,line_number)
```

## `production_input`

Identifying batch input lines, each linked to one negative inventory movement.

Primary key: `production_batch_id,line_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `production_batch_id` | `BIGINT UNSIGNED` | PK/FK | No | Production batch id. See table purpose and constraints for operational context. |
| `line_number` | `SMALLINT UNSIGNED` | PK | No | Line number. See table purpose and constraints for operational context. |
| `ingredient_product_id` | `INT UNSIGNED` | FK | No | Ingredient product id. See table purpose and constraints for operational context. |
| `quantity` | `INT UNSIGNED` |  | No | Quantity. See table purpose and constraints for operational context. |
| `cost_amount` | `DECIMAL(12,2)` |  | No | Cost amount. See table purpose and constraints for operational context. |

- `fk_input_batch`: (`production_batch_id`) → `production_batch` (`production_batch_id`).
- `fk_input_product`: (`ingredient_product_id`) → `product` (`product_id`).

```sql
production_batch_id BIGINT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    ingredient_product_id INT UNSIGNED NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    cost_amount DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (production_batch_id,line_number),
    CONSTRAINT uq_production_ingredient UNIQUE (production_batch_id,ingredient_product_id),
    CONSTRAINT chk_production_input CHECK (line_number>0 AND quantity>0 AND cost_amount>=0),
    CONSTRAINT fk_input_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_input_product FOREIGN KEY (ingredient_product_id) REFERENCES product (product_id)
```

## `prepared_food_allocation`

Associative entity allocating finished batches to sale lines; supports split batches and mixed baskets.

Primary key: `production_batch_id,sale_id,sale_line_number`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `production_batch_id` | `BIGINT UNSIGNED` | PK/FK | No | Production batch id. See table purpose and constraints for operational context. |
| `sale_id` | `BIGINT UNSIGNED` | PK/FK | No | Sale id. See table purpose and constraints for operational context. |
| `sale_line_number` | `SMALLINT UNSIGNED` | PK/FK | No | Sale line number. See table purpose and constraints for operational context. |
| `quantity` | `SMALLINT UNSIGNED` |  | No | Quantity. See table purpose and constraints for operational context. |

- `fk_allocation_batch`: (`production_batch_id`) → `production_batch` (`production_batch_id`).
- `fk_allocation_sale`: (`sale_id,sale_line_number`) → `sale_item` (`sale_id,line_number`).

```sql
production_batch_id BIGINT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NOT NULL,
    sale_line_number SMALLINT UNSIGNED NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (production_batch_id,sale_id,sale_line_number),
    CONSTRAINT chk_food_allocation CHECK (quantity>0),
    CONSTRAINT fk_allocation_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_allocation_sale FOREIGN KEY (sale_id,sale_line_number) REFERENCES sale_item (sale_id,line_number)
```

## `production_disposal`

Associative entity linking unsold batch quantities to spoilage adjustments.

Primary key: `production_batch_id,adjustment_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `production_batch_id` | `BIGINT UNSIGNED` | PK/FK | No | Production batch id. See table purpose and constraints for operational context. |
| `adjustment_id` | `BIGINT UNSIGNED` | PK/FK | No | Adjustment id. See table purpose and constraints for operational context. |
| `quantity` | `INT UNSIGNED` |  | No | Quantity. See table purpose and constraints for operational context. |

- `fk_disposal_batch`: (`production_batch_id`) → `production_batch` (`production_batch_id`).
- `fk_disposal_adjustment`: (`adjustment_id`) → `inventory_adjustment` (`adjustment_id`).

```sql
production_batch_id BIGINT UNSIGNED NOT NULL,
    adjustment_id BIGINT UNSIGNED NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    PRIMARY KEY (production_batch_id,adjustment_id),
    CONSTRAINT uq_disposal_adjustment UNIQUE (adjustment_id),
    CONSTRAINT chk_disposal_quantity CHECK (quantity>0),
    CONSTRAINT fk_disposal_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_disposal_adjustment FOREIGN KEY (adjustment_id) REFERENCES inventory_adjustment (adjustment_id)
```

## `daily_labor`

Daily role/department staffing costs aggregate to monthly wages, employer costs and benefits.

Primary key: `store_id,work_date,department_id,job_role_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Store id. See table purpose and constraints for operational context. |
| `work_date` | `DATE` | PK | No | Work date. See table purpose and constraints for operational context. |
| `department_id` | `TINYINT UNSIGNED` | PK/FK | No | Department id. See table purpose and constraints for operational context. |
| `job_role_id` | `TINYINT UNSIGNED` | PK/FK | No | Job role id. See table purpose and constraints for operational context. |
| `paid_hours` | `DECIMAL(8,2)` |  | No | Aggregate scheduled role/department hours, not individual employee clock punches. |
| `hourly_rate` | `DECIMAL(7,2)` |  | No | Hourly rate. See table purpose and constraints for operational context. |
| `wage_amount` | `DECIMAL(12,2)` |  | No | ROUND(paid_hours*hourly_rate,2), using decimal half-up rounding. |
| `employer_cost` | `DECIMAL(12,2)` |  | No | Employer cost. See table purpose and constraints for operational context. |
| `benefit_cost` | `DECIMAL(12,2)` |  | No | Benefit cost. See table purpose and constraints for operational context. |

- `fk_labor_store`: (`store_id`) → `store` (`store_id`).
- `fk_labor_department`: (`department_id`) → `department` (`department_id`).
- `fk_labor_role`: (`job_role_id`) → `job_role` (`job_role_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    work_date DATE NOT NULL,
    department_id TINYINT UNSIGNED NOT NULL,
    job_role_id TINYINT UNSIGNED NOT NULL,
    paid_hours DECIMAL(8,2) NOT NULL,
    hourly_rate DECIMAL(7,2) NOT NULL,
    wage_amount DECIMAL(12,2) NOT NULL,
    employer_cost DECIMAL(12,2) NOT NULL,
    benefit_cost DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (store_id,work_date,department_id,job_role_id),
    CONSTRAINT chk_daily_labor CHECK (paid_hours>0 AND hourly_rate>0 AND wage_amount=ROUND(paid_hours*hourly_rate,2) AND employer_cost>=0 AND benefit_cost>=0),
    CONSTRAINT fk_labor_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_labor_department FOREIGN KEY (department_id) REFERENCES department (department_id),
    CONSTRAINT fk_labor_role FOREIGN KEY (job_role_id) REFERENCES job_role (job_role_id)
```

## `dataset_metadata`

Single-row edition boundary and seed, used instead of hard-coded reporting dates.

Primary key: `dataset_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `dataset_id` | `TINYINT UNSIGNED` | PK | No | Dataset id. See table purpose and constraints for operational context. |
| `edition` | `ENUM('FIXTURE','CLASSROOM','FULL')` |  | No | Edition. See table purpose and constraints for operational context. |
| `reporting_start` | `DATE` |  | No | First complete operating date included in this edition. |
| `reporting_end` | `DATE` |  | No | Last complete operating date included in this edition; financial results are scoped to it. |
| `timezone_name` | `VARCHAR(40)` |  | No | America/New_York. DATETIME values are Lexington wall time; DST transitions occur while retail is closed. |
| `seed` | `INT UNSIGNED` |  | No | Seed. See table purpose and constraints for operational context. |


```sql
dataset_id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    edition ENUM('FIXTURE','CLASSROOM','FULL') NOT NULL,
    reporting_start DATE NOT NULL,
    reporting_end DATE NOT NULL,
    timezone_name VARCHAR(40) NOT NULL,
    seed INT UNSIGNED NOT NULL,
    CONSTRAINT chk_dataset CHECK (dataset_id=1 AND reporting_end>=reporting_start AND timezone_name='America/New_York')
```

## `inventory_movement`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `movement_id`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `movement_id` | `BIGINT UNSIGNED` | PK | No | Posting-order surrogate, breaking timestamp ties deterministically. |
| `store_id` | `SMALLINT UNSIGNED` | FK | No | Store half of inventory reference. |
| `product_id` | `INT UNSIGNED` | FK | No | Product half of inventory reference. |
| `moved_at` | `DATETIME` |  | No | Economic event timestamp; replay order is (moved_at, movement_id). |
| `movement_type` | `ENUM('SALE','RECEIPT','RETURN','ADJUSTMENT','PRODUCTION_IN','PRODUCTION_OUT')` |  | No | Exactly one typed source: SALE, RECEIPT, RETURN, ADJUSTMENT, PRODUCTION_IN or PRODUCTION_OUT. |
| `quantity_change` | `INT` |  | No | Signed package movement, negative for issues/losses and positive for receipts/returns. |
| `value_change` | `DECIMAL(14,2)` |  | No | Signed total carrying-value change in USD; receipt at PO cost, issue at moving average, return at original cost. |
| `sale_id` | `BIGINT UNSIGNED` | FK | Yes | Optional original sale source. |
| `sale_line_number` | `SMALLINT UNSIGNED` | FK | Yes | Optional original line source, paired with sale_id. |
| `receipt_id` | `INT UNSIGNED` | FK | Yes | Optional receipt source. |
| `receipt_line_number` | `SMALLINT UNSIGNED` | FK | Yes | Optional receipt line, paired with receipt_id. |
| `sale_return_id` | `BIGINT UNSIGNED` | FK | Yes | Optional return source. |
| `return_line_number` | `SMALLINT UNSIGNED` | FK | Yes | Optional return line, paired with sale_return_id. |
| `adjustment_id` | `BIGINT UNSIGNED` | FK | Yes | Optional non-sale adjustment source. UNIQUE sources prevent double posting. |
| `production_batch_id` | `BIGINT UNSIGNED` | FK | Yes | Production batch id. See table purpose and constraints for operational context. |
| `production_input_line` | `SMALLINT UNSIGNED` | FK | Yes | Production input line. See table purpose and constraints for operational context. |
| `production_output_id` | `BIGINT UNSIGNED` |  | Yes | Stored generated batch key only for PRODUCTION_IN; UNIQUE permits one output posting per batch. |

- `fk_movement_batch`: (`production_batch_id`) → `production_batch` (`production_batch_id`).
- `fk_movement_input`: (`production_batch_id,production_input_line`) → `production_input` (`production_batch_id,line_number`).
- `fk_movement_inventory`: (`store_id, product_id`) → `store_inventory` (`store_id, product_id`).
- `fk_movement_sale`: (`sale_id, sale_line_number`) → `sale_item` (`sale_id, line_number`).
- `fk_movement_receipt`: (`receipt_id, receipt_line_number`) → `receipt_line` (`receipt_id, line_number`).
- `fk_movement_return`: (`sale_return_id, return_line_number`) → `sale_return_item` (`sale_return_id, line_number`).
- `fk_movement_adjustment`: (`adjustment_id`) → `inventory_adjustment` (`adjustment_id`).

```sql
movement_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    moved_at DATETIME NOT NULL,
    movement_type ENUM('SALE','RECEIPT','RETURN','ADJUSTMENT','PRODUCTION_IN','PRODUCTION_OUT') NOT NULL,
    quantity_change INT NOT NULL,
    value_change DECIMAL(14,2) NOT NULL,
    sale_id BIGINT UNSIGNED NULL,
    sale_line_number SMALLINT UNSIGNED NULL,
    receipt_id INT UNSIGNED NULL,
    receipt_line_number SMALLINT UNSIGNED NULL,
    sale_return_id BIGINT UNSIGNED NULL,
    return_line_number SMALLINT UNSIGNED NULL,
    adjustment_id BIGINT UNSIGNED NULL,
    production_batch_id BIGINT UNSIGNED NULL,
    production_input_line SMALLINT UNSIGNED NULL,
    CONSTRAINT uq_movement_production UNIQUE (production_batch_id,production_input_line),
    production_output_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN movement_type='PRODUCTION_IN' THEN production_batch_id ELSE NULL END) STORED,
    CONSTRAINT uq_production_output UNIQUE (production_output_id),
    CONSTRAINT uq_movement_sale UNIQUE (sale_id, sale_line_number),
    CONSTRAINT uq_movement_receipt UNIQUE (receipt_id, receipt_line_number),
    CONSTRAINT uq_movement_return UNIQUE (sale_return_id, return_line_number),
    CONSTRAINT uq_movement_adjustment UNIQUE (adjustment_id),
    CONSTRAINT chk_movement_sign CHECK (
        quantity_change <> 0 AND quantity_change * value_change >= 0
        AND (movement_type <> 'SALE' OR quantity_change < 0)
        AND (movement_type NOT IN ('RECEIPT','RETURN') OR quantity_change > 0)),
    CONSTRAINT chk_movement_source CHECK (
        (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='SALE' AND sale_id IS NOT NULL AND sale_line_number IS NOT NULL
         AND receipt_id IS NULL AND receipt_line_number IS NULL AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL)
        OR (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='RECEIPT' AND receipt_id IS NOT NULL AND receipt_line_number IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL)
        OR (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='RETURN' AND sale_return_id IS NOT NULL AND return_line_number IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL AND adjustment_id IS NULL)
        OR (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='ADJUSTMENT' AND adjustment_id IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL AND sale_return_id IS NULL AND return_line_number IS NULL)
        OR (movement_type='PRODUCTION_IN' AND production_batch_id IS NOT NULL AND production_input_line IS NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL
         AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL AND quantity_change>0)
        OR (movement_type='PRODUCTION_OUT' AND production_batch_id IS NOT NULL AND production_input_line IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL
         AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL AND quantity_change<0)),
    CONSTRAINT fk_movement_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_movement_input FOREIGN KEY (production_batch_id,production_input_line) REFERENCES production_input (production_batch_id,line_number),
    CONSTRAINT fk_movement_inventory FOREIGN KEY (store_id, product_id) REFERENCES store_inventory (store_id, product_id),
    CONSTRAINT fk_movement_sale FOREIGN KEY (sale_id, sale_line_number) REFERENCES sale_item (sale_id, line_number),
    CONSTRAINT fk_movement_receipt FOREIGN KEY (receipt_id, receipt_line_number) REFERENCES receipt_line (receipt_id, line_number),
    CONSTRAINT fk_movement_return FOREIGN KEY (sale_return_id, return_line_number) REFERENCES sale_return_item (sale_return_id, line_number),
    CONSTRAINT fk_movement_adjustment FOREIGN KEY (adjustment_id) REFERENCES inventory_adjustment (adjustment_id),
    INDEX idx_movement_inventory_date (store_id, product_id, moved_at, movement_id)
```

## `store_operating_expense`

Preserved operational entity; see column definitions and enforced relationships below.

Primary key: `store_id, expense_month, expense_type`.

| Column | SQL type | Key | Nullable | Business meaning |
|---|---|---|---|---|
| `store_id` | `SMALLINT UNSIGNED` | PK/FK | No | Store whose modeled monthly budget is allocated. |
| `expense_month` | `DATE` | PK | No | First calendar date of expense month. |
| `expense_type` | `ENUM('LABOR','PAYROLL_COST','BENEFITS','OCCUPANCY','UTILITIES','INSURANCE','MAINTENANCE','PROCESSING','EQUIPMENT','SUPPLIES','DEPRECIATION','LICENSES','OTHER')` | PK | No | LABOR, OCCUPANCY, UTILITIES, or OTHER; composite PK prevents duplicate monthly type. |
| `full_store_budget` | `DECIMAL(12,2)` |  | No | Actual modeled period cost from staffing, tender fees or recurring budget; no sample allocation. |
| `allocation_rate` | `DECIMAL(7,6)` |  | No | Always 1 in v2.1. Retained v2.0 column, not an economic sampling fraction. |
| `allocated_amount` | `DECIMAL(12,2)` |  | No | Entire modeled expense. Sum with inventory loss once to determine operating income. |
| `assumption` | `VARCHAR(255)` |  | No | Basis for expense; excludes financing and income taxes. |

- `fk_expense_store`: (`store_id`) → `store` (`store_id`).

```sql
store_id SMALLINT UNSIGNED NOT NULL,
    expense_month DATE NOT NULL,
    expense_type ENUM('LABOR','PAYROLL_COST','BENEFITS','OCCUPANCY','UTILITIES','INSURANCE','MAINTENANCE','PROCESSING','EQUIPMENT','SUPPLIES','DEPRECIATION','LICENSES','OTHER') NOT NULL,
    full_store_budget DECIMAL(12,2) NOT NULL,
    allocation_rate DECIMAL(7,6) NOT NULL,
    allocated_amount DECIMAL(12,2) NOT NULL,
    assumption VARCHAR(255) NOT NULL,
    PRIMARY KEY (store_id, expense_month, expense_type),
    CONSTRAINT chk_expense CHECK (DAY(expense_month)=1 AND full_store_budget >= 0
        AND allocation_rate > 0 AND allocation_rate <= 1
        AND allocated_amount=ROUND(full_store_budget*allocation_rate,2)),
    CONSTRAINT fk_expense_store FOREIGN KEY (store_id) REFERENCES store (store_id)
```

## Reporting views

`v_sales_activity` is the dated sales/returns fact view; signed net merchandise and historical COGS exclude collected tax from revenue. `v_monthly_store_income` combines monthly activity with recurring operating expenses and inventory losses. Its operating profit excludes financing and income taxes. Views aggregate existing records; they are not additional base tables.
