-- Read-only installation smoke checks. This does not replace the full 271 audits.
USE hearth_holler_grocery_v21;
SELECT 'edition_and_period' AS check_name,IF(COUNT(*)=1,'PASS','FAIL') AS result FROM dataset_metadata WHERE edition='CLASSROOM' AND reporting_start='2025-01-01' AND reporting_end='2025-03-31';
SELECT 'two_Lexington_stores' AS check_name,IF(COUNT(*)=2 AND SUM(city='Lexington' AND is_active=1)=2,'PASS','FAIL') AS result FROM store;
SELECT 'base_tables' AS check_name,IF(COUNT(*)=44,'PASS','FAIL') AS result FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE';
SELECT 'sale_count' AS check_name,IF(COUNT(*)=127376,'PASS','FAIL') AS result,COUNT(*) AS actual_count,127376 AS expected_count FROM sale;
SELECT 'sale_item_count' AS check_name,IF(COUNT(*)=674041,'PASS','FAIL') AS result,COUNT(*) AS actual_count,674041 AS expected_count FROM sale_item;
SELECT 'inventory_movement_count' AS check_name,IF(COUNT(*)=828545,'PASS','FAIL') AS result,COUNT(*) AS actual_count,828545 AS expected_count FROM inventory_movement;
SELECT 'production_batch_count' AS check_name,IF(COUNT(*)=23867,'PASS','FAIL') AS result,COUNT(*) AS actual_count,23867 AS expected_count FROM production_batch;
SELECT 'production_input_count' AS check_name,IF(COUNT(*)=93186,'PASS','FAIL') AS result,COUNT(*) AS actual_count,93186 AS expected_count FROM production_input;
SELECT 'sale_payment_count' AS check_name,IF(COUNT(*)=134792,'PASS','FAIL') AS result,COUNT(*) AS actual_count,134792 AS expected_count FROM sale_payment;
SELECT 'retail_calendar_coverage' AS check_name,IF(COUNT(DISTINCT store_id,trading_date)=2*((SELECT DATEDIFF(reporting_end,reporting_start)+1 FROM dataset_metadata)),'PASS','FAIL') AS result FROM sale;
SELECT 'original_tender_reconciliation' AS check_name,IF((SELECT COALESCE(SUM(amount),0) FROM sale_payment)=(SELECT COALESCE(SUM(grand_total),0) FROM sale WHERE sale_status<>'VOIDED'),'PASS','FAIL') AS result;
SELECT 'refund_tender_reconciliation' AS check_name,IF((SELECT COALESCE(SUM(amount),0) FROM sale_refund)=(SELECT COALESCE(SUM(refund_total),0) FROM sale_return),'PASS','FAIL') AS result;
SELECT 'food_production_present' AS check_name,IF(SUM(store_id=1 AND production_method='MADE_TO_ORDER')>0 AND SUM(store_id=2 AND production_method='BATCH')>0,'PASS','FAIL') AS result FROM production_batch;
SELECT 'bar_present' AS check_name,IF(COUNT(*)>0 AND SUM(s.store_id<>1)=0,'PASS','FAIL') AS result FROM sale_item l JOIN sale s USING(sale_id) WHERE l.service_channel='BAR';
