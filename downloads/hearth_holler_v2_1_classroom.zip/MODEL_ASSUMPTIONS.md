# v2.1 model and accounting policy

The data describe an independently operated fictional two-store grocery, not a cooperative. Store 1 retains its key as Downtown Lexington; store 2 is deliberately remapped from the former v2.0 location to South Lexington. No keys 3–5 remain in active operational data. Archived v2.0 preserves its original five-store history.

## Formats and schedules

Downtown (6,000 square feet) operates Mon–Thu 06:00–22:00, Fri–Sat 06:00–next-day 00:00, Sun 07:00–20:00. South (18,000 square feet) operates Mon–Sat 07:00–22:00, Sun 07:00–20:00. All timestamps are America/New_York wall-time DATETIME. Closing boundaries are excluded. DST transitions occur outside retail hours. Every calendar day is open in this fictional scenario, with reduced Thanksgiving/Christmas demand rather than special holiday closures.

Downtown's exposed griddle prepares against sale-line orders. Ingredient and packaging stock is issued, finished product posted, and then sold at completion. Four minutes of elapsed preparation is a simplified timing assumption; concurrent orders are allowed. South produces recipes in batches at 06:30 after a 06:00 start, then allocates units to grab-and-go sales. Breakfast/coffee expires after four hours; refrigerated lunch foods after sixteen. Unsold goods are disposed at day end; expired units cannot be sold. Batch forecasts are fixed stochastic daily plans, not a sophisticated adaptive production optimizer. Downtown also stocks inherited supplier-made packaged deli wraps and salads (category 12) as RESALE products. Their vendor production is outside this business ledger; they consume purchased stock and appear in the GROCERY service channel and deli category. In-house Downtown recipe products use made-to-order production. The GRAB_GO channel specifically identifies South's in-house batch products.

The Downtown bar is a department, never a third store. Whole served beer bottles and sealed retail six-packs have different SKUs. No draft keg conversion, tips, patron identities or age-verification log is modeled. Alcohol permissions and schedules are hypothetical as described in RESEARCH_AND_ASSUMPTIONS.md.

## Demand and merchandising

A fixed seed drives daily count variation, skewed basket sizes, anonymous purchases, repeat customers, hourly peaks, weekday/weekend patterns and stock availability. Planning centers are 500 and 1,000 tickets/day with $22 and $43 pre-tax tickets. Observed totals are never rescaled. Category/SKU prices and supplier quotes vary, with selected Downtown convenience premiums and competitive shared staples. Procurement uses supplier quotes at order time; receipts capitalize actual order cost. Purchase commitments are not expenses or cash payments.

Seasonal multipliers, holiday preparation, fall local-event Saturdays, a fictional cold snap and refrigeration disruption affect traffic. They are not observed Lexington weather or event records. Category weights separately increase summer grilling proteins and beverages, back-to-school cereal/snacks, Easter dairy, Thanksgiving/Christmas pantry and meal ingredients, and cold-snap pantry demand. These are fictional mix assumptions, not measured local elasticities. Family packages and shopping occasions distinguish stores without demographic stereotypes.

Anonymous transactions and loyalty-linked repeats coexist. Customers and brands are fictional; no sensitive customer profiling is generated. Empty desired baskets are abandoned and unavailable selections are omitted, so shortages constrain actual sales. Generator counters describe attempted selections and are not customer complaint records. Supplier lead times, partial receipts and missed deliveries are modeled, but no supplier accounts-payable/cash-disbursement ledger is included.

## Accounting

- Line gross merchandise is quantity times historical selling price. Subtract discounts to obtain net merchandise sales; tax is separate. Voids retain quoted lines but post no revenue, tender or inventory.
- `v_sales_activity` recognizes sales at checkout and returns at the return timestamp, reversing original discounted merchandise, tax and realized COGS. `sale_status='COMPLETED'` alone is a narrower ticket-cohort selection.
- Historical COGS uses perpetual store/SKU moving-average value immediately before issue, rounded to integer cents. Returns restore original issued cost. Current `product.unit_cost` is a planning estimate, not historical COGS.
- Recipe ingredient and packaging costs move into finished stock and then COGS. Ingredients are not depleted again at prepared-food checkout. Labor is never capitalized: daily staffing wages, employer costs and benefits appear once in monthly operating expenses. Recipe labor minutes are memo measures, not payroll charges.
- Inventory adjustments, including food disposal, are charged once below gross profit in the operating statement. The movement ledger separates them from merchandise COGS. Compare external grocery gross margins cautiously because shrink accounting classifications can differ.
- `v_monthly_store_income` subtracts recurring expenses and inventory losses from gross profit. Its result is **operating profit before financing and income taxes**, not after-tax net profit or an audited complete financial statement.
- Monthly recurring expense assumptions are set before simulation; labor follows hours/weekends and a 2026 wage change, tender fees follow payments. Occupancy and most nonlabor budgets are fixed by store. Utility seasonality is not separately modeled.
- All decimal wage calculations use half-up cents rounding. Card processing fees use the generator's documented Decimal quantization. There is no expense adjustment to hit a target profit margin.

## Editions and boundaries

FULL: January 1, 2025–September 30, 2026 (638 days). CLASSROOM: January 1–March 31, 2025 (90 days), extracted from the same retained transactions and movements. Classroom opening balances equal full opening balances; closing inventory, loyalty and statuses are recomputed as of March 31. Orders outstanding at March 31 remain open/partial, with later receipts excluded. Later refunds are excluded and closing ticket status recomputed.

Classroom has no promotional campaigns or within-period price changes; its introductory, production, inventory and financial exercises remain meaningful. Promotion and annual comparison questions explicitly require FULL. Reporting-period revenue must never be described as the full company's 21-month revenue. The final days in either edition are naturally right-censored for future returns.

This is internally testable synthetic data, not observed business performance. Final reports distinguish hard relational/financial checks from soft economic diagnostics. Any material unmet behavioral requirement is listed rather than silently declared complete.

Returns receive independently seeded service-hour arrival times, concentrated around midday. Return and sale events are processed together in chronological order, so restored stock and original-cost reversals become available only at the actual return time. Earlier opening-batch and fixed-08:00 candidates remain archived as development history.

Procurement forecasts use the preserved first 14-day pilot's store/category unit demand (normalized for January seasonality), allocated to SKU popularity within category. This avoids the prior category-blind forecast. Perishables hold 2/3 safety days plus 2/3 cycle days at Downtown/South; shelf-stable stock holds 10/16 safety days plus 4/7 cycle days, in addition to supplier lead-time demand. Actual stockouts constrain selection. This deliberately simple fixed forecast does not know future sales. Recipe inputs use planned recipe demand; food production does not purchase finished in-house products.

South coffee planning is 24 daily units before stochastic variation, reduced from 32 after the pilot revealed 36.8% annual coffee disposal. All recipes retain stochastic production and actual unsold/expired disposal; no waste percentage is imposed.

Legacy energy beverages (products 21–25) are assumed sweetened soft drinks and taxed at 6%. Plain water and unprepared coffee beans remain qualifying grocery assumptions. Supplier-made cold packaged deli goods are assumed sold without heating or retailer utensils. These composition/service assumptions are disclosed rather than asserted as legal rulings.

Register attribution uses active cashiers, cross-trained stock clerks and assistant managers hired before the trading date. Each has five eligible days per week and belongs to one nonoverlapping register window per day, at most eight hours. Independent deterministic assignment avoids changing demand or money. These windows describe permitted register attribution, not individual paid shifts or time-clock records; aggregate daily labor remains the sole payroll posting.
