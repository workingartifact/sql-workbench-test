# Hearth & Holler v2.1 — student installation

AN/MKT 324. Use the **classroom** archive. Extract the ZIP completely before opening SQL files. No Python, generator, Docker, or development tools are required.

## Install the two MySQL applications

**MySQL Community Server 8.4 LTS** stores and runs the database. **MySQL Workbench** is the graphical application used to connect and write SQL. Installing Workbench alone does not install or start Server.

Download Server 8.4 LTS from [MySQL Community Server](https://dev.mysql.com/downloads/mysql/8.4.html) and Workbench from [MySQL Workbench](https://dev.mysql.com/downloads/workbench/). Select the installer matching your operating system and processor. Use the instructor's specified Workbench version where available; these instructions do not claim Workbench 26 GUI testing.

- **Windows:** install and configure Server, keeping its local TCP port (normally 3306), setting a root password, and enabling its Windows service. Record the actual service name and port. Install Workbench separately. Start Server through Windows Services if necessary.
- **macOS:** use the Server package for your processor (Apple Silicon/ARM or Intel/x86). Record the password and start Server through its installed MySQL settings/startup controls. Install the compatible Workbench application separately. Do not install a second server over an existing working installation.

Keep your database password private. It is not your computer login password unless you deliberately made them the same.

## Connect in Workbench

Create a local connection using Standard TCP/IP, hostname `127.0.0.1`, port `3306` (or the port selected during your installation), username `root` (or your instructor-approved account), and the database password. Test the connection, then open it. This project's developer test port 33384 is **not** the normal student port.

Run this in a new SQL tab:

```sql
SELECT VERSION(), @@port;
```

The server version must be 8.4.x. The Workbench application version is separate.

## Load the classroom database

Use a fresh database name `hearth_holler_grocery_v21`. The schema script intentionally refuses to replace a database that already exists. Do not import v2.0 data or mix editions in this schema.

1. Open `01_create_schema.sql` in the connected SQL editor. Clear any text selection and execute the entire script. Check the action/output panel for errors.
2. Run `02_insert_data.sql` in the same connection. For a large file, use **File > Run SQL Script** if your Workbench version offers it; select UTF-8. Otherwise open the script and execute **all**, not just the statement under the cursor. Wait for completion and check for errors. Do not edit the data file or execute it twice.
3. Refresh the Schemas panel. Double-click `hearth_holler_grocery_v21` to make it the default schema.
4. Open and execute `06_verify_installation.sql`. Every verification result should say PASS. Confirm the CLASSROOM edition and January 1–March 31, 2025 reporting period.
5. Open `07_first_day_queries.sql`. Execute one SELECT at a time and inspect the results.

The SQL files include `USE hearth_holler_grocery_v21;`. Do not use Workbench's model/reverse-engineering wizard to install the data. Numerical instructor answers are distributed separately.

## Command-line alternative

This avoids loading the large SQL file into an editor. Open the MySQL command-line client with a password prompt. Windows PowerShell example (adjust the installation path if needed):

```powershell
& 'C:\Program Files\MySQL\MySQL Server 8.4\bin\mysql.exe' --host=127.0.0.1 --port=3306 --user=root --password --default-character-set=utf8mb4
```

macOS Terminal example for the Oracle package:

```sh
/usr/local/mysql/bin/mysql --host=127.0.0.1 --port=3306 --user=root --password --default-character-set=utf8mb4
```

At the `mysql>` prompt, use your actual extracted folder path, forward slashes, and one command per line:

```text
source C:/HH_Classroom/01_create_schema.sql
source C:/HH_Classroom/02_insert_data.sql
source C:/HH_Classroom/06_verify_installation.sql
```

On macOS replace `C:/HH_Classroom/` with, for example, `/Users/yourname/Downloads/HH_Classroom/`. A short folder path without spaces is easiest. `source` is a mysql-client command; do not paste it into Workbench's SQL editor. Stop if an error appears; a later successful statement does not prove the complete import succeeded.

## Troubleshooting

| Symptom | Action |
|---|---|
| Cannot connect / connection refused | Check that **Server** is installed and running. Start its Windows service or macOS MySQL server control. Confirm hostname and actual port. Reopening Workbench does not start Server. |
| Access denied | Recheck username and database password. Remove an outdated saved Workbench password and re-enter it. If forgotten, ask the instructor for the official server-account recovery procedure; do not delete the data directory or reinstall over existing databases. |
| No schema appears | Refresh Schemas. Run `SHOW DATABASES;`. Confirm you are connected to the same server and port used for import; inspect the first import error. |
| No database selected (1046) | Execute `USE hearth_holler_grocery_v21;` or double-click that schema. |
| Database already exists (1007) | Stop. This may be a working prior installation. Run the verification script first. Ask the instructor before resetting anything. |
| Duplicate key (1062) | Data may already be loaded or a previous import partly succeeded. Do not repeatedly rerun INSERT statements. Verify first and give the instructor the first error. |
| Script stops / disconnects / memory issue | Keep the computer awake, check disk space and server status, and use the command-line alternative. Preserve the first error and line number. A transaction may roll back on disconnect; tables alone do not prove data loaded. |
| Import partly failed | Stop and preserve the error. The instructor can authorize resetting **only this v2.1 schema**, then rerunning schema and data in order. No automatic reset is included in the student package. |
| Missing table / wrong results | Confirm `SELECT DATABASE();`, edition, reporting dates, and row counts using the verification script. |

## Testing scope and references

Release evidence documents Windows command-line execution on an isolated MySQL 8.4.11 server. macOS installation and Workbench GUI interaction have not been executed. The SQL is ordinary MySQL 8.4 SQL and can be submitted through a compatible Workbench connection; platform GUI steps are documented guidance, not a claimed test.

Official references: [SQL editor toolbar](https://dev.mysql.com/doc/workbench/en/wb-sql-editor-toolbar.html), [Windows service](https://dev.mysql.com/doc/refman/8.4/en/windows-start-service.html), [server startup methods](https://dev.mysql.com/doc/refman/8.4/en/automatic-start.html), [MySQL large-script workflow](https://planet.mysql.com/entry/?id=1900023).
