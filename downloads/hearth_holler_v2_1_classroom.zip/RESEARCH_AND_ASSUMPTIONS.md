# Research and modeling assumptions — v2.1

Retrieved October 9, 2026. Fictional design assumptions are not evidence of legal compliance or observations of Lexington shoppers.

## Economic reference

[FMS/NGA 2025 study publisher summary](https://fmssolutions.com/resource-grocery/2025-independent-grocers-financial-report/), June 25, 2025, reports 8,609 weekly transactions per store, 27.4% gross margin and 1.9% net profit for its benchmark population; labor/benefits 16.3% of sales and inventory turns 17.8. Its fiscal coverage is not identical to our 638-day scenario. User-specified store targets (500/$22 and 1,000/$43 daily transactions/pre-tax ticket) are planning assumptions, not values to force into final records.

## Beer service

[Kentucky ABC license types](https://abc.ky.gov/Documents/804KAR4400MIR.pdf) distinguishes NQ retail malt-beverage package permission from NQ4 malt-beverage drink permission. [Lexington ABC](https://www.lexingtonky.gov/government/departments-programs/public-safety/police/bureau-investigation/alcoholic-beverage-control-office) requires state and local licensing, premises review and server training. A grocery package license alone does not authorize this bar.

Hypothesis: Downtown has separately approved malt-beverage drink and package permissions, appropriately approved premises and trained adult servers. South has package permission only. No actual license, zoning approval, premise eligibility or historical ordinance compliance has been verified. No spirits, wine, off-site delivery, patron age data or cooperative ownership is modeled.

Model bar schedule: Mon-Thu 16:00-21:30; Fri-Sat 16:00-23:30; Sunday 13:00-19:30. Package beer is available only 09:00-close Mon-Sat and 13:00-close Sunday. These deliberately restricted fictional schedules are enforced independently of grocery hours. [Lexington ordinance 3-21 mirror](https://lexington-ky.elaws.us/code/coor_ch3_sec3-21) was consulted; current availability is not proof of unchanged rules throughout 2025-26. Licensing remains a documented hypothetical assumption.

## Tax and costing

[Kentucky Revenue sales/use tax](https://revenue.ky.gov/Business/Sales-Use-Tax/Pages/default.aspx) states a 6% state rate and no local sales/use tax. [Food classification guidance](https://revenue.ky.gov/DOR%20Training%20Materials/Sales%20Tax%20Facts%202014%20-%20Dec.pdf) distinguishes qualifying food from prepared food, candy, soft drinks and alcohol. [Prepared-food guidance](https://revenue.ky.gov/Business/Sales-Use-Tax/Documents/Sales%20Tax%20Facts-JUN%202021.pdf) explains heated/mixed/utensil-served food and the bakery exception.

Use explicit SKU tax classifications: qualifying packaged grocery ingredients 0%; prepared food, served coffee, beer, soft drinks and nonfood supplies 6%. Model classification is instructional and not an item-by-item tax ruling. Supplier beer cost includes upstream distributor taxes; do not add wholesale tax again at checkout. License expense belongs in operating expenses. No customer surcharges or tips are generated. Income taxes, financing and a balance sheet remain outside operating-income scope.

Weather and local-event demand shocks will be labeled fictional simulations, never actual observed weather. No demographic causation is used. Assumptions must be fixed before final generation and plausibility diagnostics must report deviations.
