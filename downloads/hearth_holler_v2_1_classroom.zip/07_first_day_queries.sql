-- AN/MKT 324: first SQL statements. Read-only; run one SELECT at a time.
USE hearth_holler_grocery_v21;

-- 1. Which stores are in our database?
SELECT store_id, store_name, city
FROM store
ORDER BY store_id;

-- 2. Show ten grocery products and their catalog prices.
SELECT product_id, product_name, package_size, list_price
FROM product
WHERE product_type = 'RESALE' AND is_sellable = 1
ORDER BY product_name, product_id
LIMIT 10;

-- 3. Show the first ten recorded purchases.
SELECT sale_id, store_id, sold_at, subtotal, discount_total, tax_total, grand_total
FROM sale
ORDER BY sold_at, sale_id
LIMIT 10;

-- 4. How many recorded tickets does each store have, including voids?
SELECT store_id, COUNT(*) AS recorded_tickets
FROM sale
GROUP BY store_id
ORDER BY store_id;

-- 5. Explore traffic by hour (all recorded tickets).
SELECT store_id, HOUR(sold_at) AS sale_hour, COUNT(*) AS recorded_tickets
FROM sale
GROUP BY store_id, HOUR(sold_at)
ORDER BY store_id, sale_hour;

-- 6. An instructor preview: dated sales less returns; tax is not revenue.
SELECT store_id, SUM(net_sales) AS net_sales, SUM(cogs) AS cogs,
       SUM(net_sales-cogs) AS gross_profit
FROM v_sales_activity
GROUP BY store_id
ORDER BY store_id;
