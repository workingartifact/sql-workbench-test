-- Hearth & Holler Grocers v2.1 | AN/MKT 324 | MySQL 8.4 LTS
-- SAFE FIRST INSTALL: fails if the v2.1 database already exists. No automatic DROP.
-- To intentionally reset v2.1, read and run 00_reset_v21.sql first.
-- The original hearth_holler_grocery database is never referenced.
CREATE DATABASE hearth_holler_grocery_v21 CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE hearth_holler_grocery_v21;
SET SESSION default_storage_engine = 'InnoDB';

CREATE TABLE store_region (
    region_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    region_name VARCHAR(60) NOT NULL UNIQUE,
    regional_office_city VARCHAR(60) NOT NULL,
    description VARCHAR(255) NULL
);

CREATE TABLE store (
    store_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    region_id TINYINT UNSIGNED NOT NULL,
    store_number CHAR(4) NOT NULL UNIQUE,
    store_name VARCHAR(100) NOT NULL,
    street_address VARCHAR(120) NOT NULL,
    city VARCHAR(60) NOT NULL,
    state_code CHAR(2) NOT NULL DEFAULT 'KY',
    postal_code CHAR(5) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    opened_date DATE NOT NULL,
    square_feet INT UNSIGNED NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_store_square_feet CHECK (square_feet BETWEEN 5000 AND 200000),
    CONSTRAINT fk_store_region FOREIGN KEY (region_id)
        REFERENCES store_region (region_id)
);

CREATE TABLE department (
    department_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(60) NOT NULL UNIQUE,
    description VARCHAR(255) NULL
);

CREATE TABLE job_role (
    job_role_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(60) NOT NULL UNIQUE,
    minimum_hourly_rate DECIMAL(6,2) NOT NULL,
    maximum_hourly_rate DECIMAL(6,2) NOT NULL,
    is_management BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT chk_job_role_rates CHECK (
        minimum_hourly_rate > 0 AND maximum_hourly_rate >= minimum_hourly_rate
    )
);

CREATE TABLE employee (
    employee_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    job_role_id TINYINT UNSIGNED NOT NULL,
    department_id TINYINT UNSIGNED NULL,
    manager_employee_id INT UNSIGNED NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    hire_date DATE NOT NULL,
    hourly_rate DECIMAL(6,2) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    employment_status ENUM('ACTIVE', 'LEAVE', 'FORMER') NOT NULL DEFAULT 'ACTIVE',
    CONSTRAINT chk_employee_rate CHECK (hourly_rate > 0),
    CONSTRAINT fk_employee_store FOREIGN KEY (store_id)
        REFERENCES store (store_id),
    CONSTRAINT fk_employee_job_role FOREIGN KEY (job_role_id)
        REFERENCES job_role (job_role_id),
    CONSTRAINT fk_employee_department FOREIGN KEY (department_id)
        REFERENCES department (department_id),
    CONSTRAINT fk_employee_manager FOREIGN KEY (manager_employee_id)
        REFERENCES employee (employee_id)
        ON DELETE SET NULL
);

CREATE TABLE category (
    category_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_id TINYINT UNSIGNED NOT NULL,
    category_name VARCHAR(60) NOT NULL UNIQUE,
    shelf_life_class ENUM('PERISHABLE', 'SEMI_PERISHABLE', 'SHELF_STABLE') NOT NULL,
    CONSTRAINT fk_category_department FOREIGN KEY (department_id)
        REFERENCES department (department_id)
);

CREATE TABLE brand (
    brand_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    brand_name VARCHAR(80) NOT NULL UNIQUE,
    brand_tagline VARCHAR(160) NULL,
    home_city VARCHAR(60) NOT NULL,
    home_state_code CHAR(2) NOT NULL,
    is_store_brand BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE product (
    product_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    brand_id SMALLINT UNSIGNED NOT NULL,
    category_id TINYINT UNSIGNED NOT NULL,
    sku VARCHAR(20) NOT NULL UNIQUE,
    upc CHAR(12) NOT NULL UNIQUE,
    product_name VARCHAR(120) NOT NULL,
    package_size VARCHAR(40) NOT NULL,
    unit_of_measure ENUM('EACH', 'OUNCE', 'POUND', 'FLUID_OUNCE', 'COUNT') NOT NULL,
    list_price DECIMAL(8,2) NOT NULL,
    unit_cost DECIMAL(8,2) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    introduced_date DATE NOT NULL,
    product_type ENUM('RESALE','INGREDIENT','PACKAGING','PREPARED','BAR') NOT NULL DEFAULT 'RESALE',
    tax_rate DECIMAL(5,4) NOT NULL DEFAULT 0,
    is_sellable BOOLEAN NOT NULL DEFAULT TRUE,
    food_period ENUM('ALL','BREAKFAST','LUNCH') NOT NULL DEFAULT 'ALL',
    CONSTRAINT chk_product_tax CHECK (tax_rate IN (0,0.06)),
    CONSTRAINT uq_product_brand_name_size UNIQUE (brand_id, product_name, package_size),
    CONSTRAINT chk_product_prices CHECK (
        list_price >= 0 AND unit_cost >= 0 AND list_price >= unit_cost
    ),
    CONSTRAINT fk_product_brand FOREIGN KEY (brand_id)
        REFERENCES brand (brand_id),
    CONSTRAINT fk_product_category FOREIGN KEY (category_id)
        REFERENCES category (category_id)
);

CREATE TABLE supplier (
    supplier_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL UNIQUE,
    contact_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    city VARCHAR(60) NOT NULL,
    state_code CHAR(2) NOT NULL,
    lead_time_days TINYINT UNSIGNED NOT NULL,
    supplier_rating DECIMAL(3,2) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_supplier_lead_time CHECK (lead_time_days BETWEEN 1 AND 60),
    CONSTRAINT chk_supplier_rating CHECK (supplier_rating BETWEEN 1.00 AND 5.00)
);

-- Resolves the many-to-many relationship between products and suppliers.
CREATE TABLE product_supplier (
    product_id INT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    supplier_product_code VARCHAR(30) NOT NULL,
    wholesale_cost DECIMAL(8,2) NOT NULL,
    is_primary_supplier BOOLEAN NOT NULL DEFAULT FALSE,
    minimum_order_quantity SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (product_id, supplier_id),
    UNIQUE (supplier_id, supplier_product_code),
    CONSTRAINT chk_product_supplier_cost CHECK (wholesale_cost >= 0),
    CONSTRAINT chk_product_supplier_moq CHECK (minimum_order_quantity > 0),
    CONSTRAINT fk_product_supplier_product FOREIGN KEY (product_id)
        REFERENCES product (product_id),
    CONSTRAINT fk_product_supplier_supplier FOREIGN KEY (supplier_id)
        REFERENCES supplier (supplier_id)
);

-- A row exists only when a particular store carries a particular product.
CREATE TABLE store_inventory (
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    quantity_on_hand INT UNSIGNED NOT NULL DEFAULT 0,
    inventory_value DECIMAL(14,2) NOT NULL DEFAULT 0,
    CONSTRAINT chk_inventory_value CHECK (inventory_value >= 0),
    reorder_point INT UNSIGNED NOT NULL,
    reorder_quantity INT UNSIGNED NOT NULL,
    shelf_location VARCHAR(20) NOT NULL,
    last_counted_at DATETIME NOT NULL,
    PRIMARY KEY (store_id, product_id),
    CONSTRAINT chk_inventory_levels CHECK (
        reorder_quantity > 0 AND reorder_point >= 0
    ),
    CONSTRAINT fk_inventory_store FOREIGN KEY (store_id)
        REFERENCES store (store_id),
    CONSTRAINT fk_inventory_product FOREIGN KEY (product_id)
        REFERENCES product (product_id)
);

CREATE TABLE customer (
    customer_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(120) NULL UNIQUE,
    phone VARCHAR(20) NULL,
    city VARCHAR(60) NOT NULL,
    state_code CHAR(2) NOT NULL DEFAULT 'KY',
    postal_code CHAR(5) NOT NULL,
    birth_year YEAR NULL,
    created_at DATETIME NOT NULL,
    marketing_opt_in BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT chk_customer_birth_year CHECK (birth_year IS NULL OR birth_year BETWEEN 1920 AND 2010)
);

CREATE TABLE loyalty_account (
    loyalty_account_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL UNIQUE,
    loyalty_number CHAR(10) NOT NULL UNIQUE,
    joined_date DATE NOT NULL,
    points_balance INT UNSIGNED NOT NULL DEFAULT 0,
    tier ENUM('SPROUT', 'SAPLING', 'MIGHTY_OAK') NOT NULL DEFAULT 'SPROUT',
    CONSTRAINT fk_loyalty_customer FOREIGN KEY (customer_id)
        REFERENCES customer (customer_id)
);

CREATE TABLE payment_method (
    payment_method_id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(40) NOT NULL UNIQUE,
    processing_fee_rate DECIMAL(5,4) NOT NULL DEFAULT 0,
    CONSTRAINT chk_payment_fee CHECK (processing_fee_rate BETWEEN 0 AND 0.1000)
);

CREATE TABLE sale (
    sale_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    customer_id INT UNSIGNED NULL,
    employee_id INT UNSIGNED NOT NULL,
    sold_at DATETIME NOT NULL,
    trading_date DATE NOT NULL,
    purchase_occasion ENUM('BREAKFAST','LUNCH','TOP_UP','WEEKLY','DINNER','BAR') NOT NULL,
    CONSTRAINT chk_sale_trading_date CHECK (DATE(sold_at) BETWEEN trading_date AND DATE_ADD(trading_date,INTERVAL 1 DAY)),
    sale_status ENUM('COMPLETED', 'RETURNED', 'VOIDED') NOT NULL DEFAULT 'COMPLETED',
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    tax_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    grand_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT chk_sale_totals CHECK (
        subtotal >= 0 AND discount_total >= 0 AND tax_total >= 0 AND grand_total >= 0
    ),
    INDEX idx_sale_sold_at (sold_at),
    INDEX idx_sale_store_date (store_id, sold_at),
    INDEX idx_sale_customer (customer_id),
    CONSTRAINT fk_sale_store FOREIGN KEY (store_id)
        REFERENCES store (store_id),
    CONSTRAINT fk_sale_customer FOREIGN KEY (customer_id)
        REFERENCES customer (customer_id)
        ON DELETE SET NULL,
    CONSTRAINT fk_sale_employee FOREIGN KEY (employee_id)
        REFERENCES employee (employee_id)
);

-- An identifying child: line_number has meaning only within its parent sale.
CREATE TABLE sale_item (
    service_channel ENUM('GROCERY','GRIDDLE','GRAB_GO','BAR') NOT NULL DEFAULT 'GROCERY',
    sale_id BIGINT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    unit_price DECIMAL(8,2) NOT NULL,
    discount_amount DECIMAL(8,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(8,2) NOT NULL,
    cost_amount DECIMAL(12,2) NOT NULL,
    CONSTRAINT chk_sale_item_financial CHECK (tax_amount >= 0 AND cost_amount >= 0),
    PRIMARY KEY (sale_id, line_number),
    CONSTRAINT uq_sale_product UNIQUE (sale_id, product_id),
    CONSTRAINT chk_sale_item_quantity CHECK (quantity > 0),
    CONSTRAINT chk_sale_item_amounts CHECK (
        unit_price >= 0 AND discount_amount >= 0
        AND discount_amount <= unit_price * quantity
    ),
    CONSTRAINT fk_sale_item_sale FOREIGN KEY (sale_id)
        REFERENCES sale (sale_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_sale_item_product FOREIGN KEY (product_id)
        REFERENCES product (product_id)
);

CREATE TABLE promotion (
    promotion_id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    promotion_name VARCHAR(100) NOT NULL UNIQUE,
    promotion_description VARCHAR(255) NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    discount_type ENUM('PERCENT', 'AMOUNT') NOT NULL,
    discount_value DECIMAL(8,2) NOT NULL,
    CONSTRAINT chk_promotion_dates CHECK (end_date >= start_date),
    CONSTRAINT chk_promotion_value CHECK (
        discount_value > 0
        AND (discount_type = 'AMOUNT' OR discount_value <= 100)
    )
);

-- Resolves the many-to-many relationship between products and promotions.
CREATE TABLE product_promotion (
    promotion_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    featured_display BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (promotion_id, product_id),
    CONSTRAINT fk_product_promotion_promotion FOREIGN KEY (promotion_id)
        REFERENCES promotion (promotion_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_product_promotion_product FOREIGN KEY (product_id)
        REFERENCES product (product_id)
);

CREATE TABLE inventory_adjustment (
    adjustment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    employee_id INT UNSIGNED NOT NULL,
    adjusted_at DATETIME NOT NULL,
    quantity_change SMALLINT NOT NULL,
    reason ENUM('DELIVERY', 'DAMAGE', 'SPOILAGE', 'COUNT_CORRECTION', 'DONATION') NOT NULL,
    notes VARCHAR(255) NULL,
    CONSTRAINT chk_adjustment_nonzero CHECK (quantity_change <> 0),
    CONSTRAINT fk_adjustment_inventory FOREIGN KEY (store_id, product_id)
        REFERENCES store_inventory (store_id, product_id),
    CONSTRAINT fk_adjustment_employee FOREIGN KEY (employee_id)
        REFERENCES employee (employee_id)
);

-- v1.1 procurement: supplier_id on the line is controlled redundancy.
-- Both composite FKs must hold; changing a line's supplier cannot bypass the PO.
CREATE TABLE purchase_order (
    purchase_order_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    ordered_by_employee_id INT UNSIGNED NOT NULL,
    ordered_at DATETIME NOT NULL,
    expected_delivery_date DATE NOT NULL,
    purchase_order_status ENUM('OPEN', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED') NOT NULL,
    CONSTRAINT uq_purchase_order_supplier UNIQUE (purchase_order_id, supplier_id),
    CONSTRAINT chk_purchase_order_dates CHECK (expected_delivery_date >= DATE(ordered_at)),
    INDEX idx_purchase_order_date (ordered_at),
    CONSTRAINT fk_purchase_order_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_purchase_order_supplier FOREIGN KEY (supplier_id) REFERENCES supplier (supplier_id),
    CONSTRAINT fk_purchase_order_employee FOREIGN KEY (ordered_by_employee_id) REFERENCES employee (employee_id)
);

CREATE TABLE purchase_order_line (
    purchase_order_id INT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    quantity_ordered SMALLINT UNSIGNED NOT NULL,
    unit_cost DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (purchase_order_id, line_number),
    CONSTRAINT uq_purchase_order_product UNIQUE (purchase_order_id, product_id),
    CONSTRAINT chk_purchase_order_line CHECK (line_number > 0 AND quantity_ordered > 0 AND unit_cost >= 0),
    CONSTRAINT fk_po_line_order_supplier FOREIGN KEY (purchase_order_id, supplier_id)
        REFERENCES purchase_order (purchase_order_id, supplier_id),
    CONSTRAINT fk_po_line_product_supplier FOREIGN KEY (product_id, supplier_id)
        REFERENCES product_supplier (product_id, supplier_id)
);

CREATE TABLE receipt (
    receipt_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    purchase_order_id INT UNSIGNED NOT NULL,
    received_by_employee_id INT UNSIGNED NOT NULL,
    received_at DATETIME NOT NULL,
    delivery_reference VARCHAR(40) NOT NULL,
    CONSTRAINT uq_receipt_order UNIQUE (receipt_id, purchase_order_id),
    CONSTRAINT uq_receipt_reference UNIQUE (purchase_order_id, delivery_reference),
    INDEX idx_receipt_date (received_at),
    CONSTRAINT fk_receipt_purchase_order FOREIGN KEY (purchase_order_id) REFERENCES purchase_order (purchase_order_id),
    CONSTRAINT fk_receipt_employee FOREIGN KEY (received_by_employee_id) REFERENCES employee (employee_id)
);

CREATE TABLE receipt_line (
    receipt_id INT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    purchase_order_id INT UNSIGNED NOT NULL,
    purchase_order_line_number SMALLINT UNSIGNED NOT NULL,
    quantity_received SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (receipt_id, line_number),
    CONSTRAINT uq_receipt_po_line UNIQUE (receipt_id, purchase_order_id, purchase_order_line_number),
    CONSTRAINT chk_receipt_line CHECK (line_number > 0 AND quantity_received > 0),
    CONSTRAINT fk_receipt_line_header FOREIGN KEY (receipt_id, purchase_order_id)
        REFERENCES receipt (receipt_id, purchase_order_id),
    CONSTRAINT fk_receipt_line_order_line FOREIGN KEY (purchase_order_id, purchase_order_line_number)
        REFERENCES purchase_order_line (purchase_order_id, line_number)
);

CREATE TABLE sale_payment (
    sale_id BIGINT UNSIGNED NOT NULL,
    payment_sequence SMALLINT UNSIGNED NOT NULL,
    payment_method_id TINYINT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (sale_id, payment_sequence),
    CONSTRAINT chk_sale_payment CHECK (payment_sequence > 0 AND amount > 0),
    CONSTRAINT fk_sale_payment_sale FOREIGN KEY (sale_id) REFERENCES sale (sale_id) ON DELETE CASCADE,
    CONSTRAINT fk_sale_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_method (payment_method_id)
);

-- An effective price lasts until the next start date; no overlapping end dates.
CREATE TABLE product_price_history (
    product_id INT UNSIGNED NOT NULL,
    effective_start_date DATE NOT NULL,
    list_price DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (product_id, effective_start_date),
    CONSTRAINT chk_price_history CHECK (list_price >= 0),
    CONSTRAINT fk_price_history_product FOREIGN KEY (product_id) REFERENCES product (product_id)
);

CREATE TABLE loyalty_transaction (
    loyalty_transaction_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loyalty_account_id INT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NULL,
    transacted_at DATETIME NOT NULL,
    transaction_type ENUM('EARN', 'REDEEM', 'ADJUST', 'EXPIRE') NOT NULL,
    points_change INT NOT NULL,
    notes VARCHAR(255) NULL,
    CONSTRAINT chk_loyalty_points CHECK (
        points_change <> 0 AND (
            (transaction_type = 'EARN' AND points_change > 0)
            OR (transaction_type IN ('REDEEM', 'EXPIRE') AND points_change < 0)
            OR transaction_type = 'ADJUST'
        )
    ),
    INDEX idx_loyalty_transaction_date (loyalty_account_id, transacted_at, loyalty_transaction_id),
    CONSTRAINT fk_loyalty_transaction_account FOREIGN KEY (loyalty_account_id) REFERENCES loyalty_account (loyalty_account_id),
    CONSTRAINT fk_loyalty_transaction_sale FOREIGN KEY (sale_id) REFERENCES sale (sale_id)
);

CREATE TABLE product_supplier_cost_history (
    product_id INT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    effective_start_date DATE NOT NULL,
    wholesale_cost DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (product_id, supplier_id, effective_start_date),
    CONSTRAINT chk_supplier_cost_history CHECK (wholesale_cost >= 0),
    CONSTRAINT fk_cost_history_product_supplier FOREIGN KEY (product_id, supplier_id)
        REFERENCES product_supplier (product_id, supplier_id)
);

-- Opening balances for the explicitly complete retained inventory universe.
CREATE TABLE inventory_opening (
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    opened_at DATETIME NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    inventory_value DECIMAL(14,2) NOT NULL,
    PRIMARY KEY (store_id, product_id),
    CONSTRAINT chk_opening_value CHECK (inventory_value >= 0 AND (quantity > 0 OR inventory_value = 0)),
    CONSTRAINT fk_opening_inventory FOREIGN KEY (store_id, product_id)
        REFERENCES store_inventory (store_id, product_id)
);
CREATE TABLE sale_return (
    sale_return_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sale_id BIGINT UNSIGNED NOT NULL,
    employee_id INT UNSIGNED NOT NULL,
    returned_at DATETIME NOT NULL,
    reason VARCHAR(100) NOT NULL,
    net_amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL,
    refund_total DECIMAL(10,2) NOT NULL,
    CONSTRAINT uq_return_sale UNIQUE (sale_return_id, sale_id),
    CONSTRAINT chk_return_total CHECK (net_amount > 0 AND tax_amount >= 0 AND refund_total = net_amount + tax_amount),
    CONSTRAINT fk_return_sale FOREIGN KEY (sale_id) REFERENCES sale (sale_id),
    CONSTRAINT fk_return_employee FOREIGN KEY (employee_id) REFERENCES employee (employee_id),
    INDEX idx_return_date (returned_at)
);
CREATE TABLE sale_return_item (
    sale_return_id BIGINT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NOT NULL,
    sale_line_number SMALLINT UNSIGNED NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    net_amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL,
    cost_amount DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (sale_return_id, line_number),
    CONSTRAINT uq_return_original_line UNIQUE (sale_return_id, sale_id, sale_line_number),
    CONSTRAINT chk_return_item CHECK (line_number > 0 AND quantity > 0 AND net_amount > 0 AND tax_amount >= 0 AND cost_amount >= 0),
    CONSTRAINT fk_return_item_header FOREIGN KEY (sale_return_id, sale_id) REFERENCES sale_return (sale_return_id, sale_id),
    CONSTRAINT fk_return_item_original FOREIGN KEY (sale_id, sale_line_number) REFERENCES sale_item (sale_id, line_number)
);
CREATE TABLE sale_refund (
    sale_return_id BIGINT UNSIGNED NOT NULL,
    refund_sequence SMALLINT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NOT NULL,
    payment_sequence SMALLINT UNSIGNED NOT NULL,
    refunded_at DATETIME NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (sale_return_id, refund_sequence),
    CONSTRAINT chk_refund_amount CHECK (refund_sequence > 0 AND amount > 0),
    CONSTRAINT fk_refund_return FOREIGN KEY (sale_return_id, sale_id) REFERENCES sale_return (sale_return_id, sale_id),
    CONSTRAINT fk_refund_payment FOREIGN KEY (sale_id, payment_sequence) REFERENCES sale_payment (sale_id, payment_sequence)
);

-- Retail and service intervals are local half-open [open,close) intervals.
CREATE TABLE store_service_hours (
    store_id SMALLINT UNSIGNED NOT NULL,
    service ENUM('RETAIL','GRIDDLE','KITCHEN','BAR','PACKAGE_BEER') NOT NULL,
    weekday_number TINYINT UNSIGNED NOT NULL,
    opens_at TIME NOT NULL,
    closes_at TIME NOT NULL,
    close_day_offset TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (store_id,service,weekday_number),
    CONSTRAINT chk_service_hours CHECK (weekday_number BETWEEN 0 AND 6 AND close_day_offset IN (0,1)
      AND TIME_TO_SEC(opens_at)>=0 AND TIME_TO_SEC(opens_at)<86400
      AND TIME_TO_SEC(closes_at)>=0 AND TIME_TO_SEC(closes_at)<86400
      AND TIME_TO_SEC(closes_at)+close_day_offset*86400>TIME_TO_SEC(opens_at)),
    CONSTRAINT fk_service_store FOREIGN KEY (store_id) REFERENCES store (store_id)
);
CREATE TABLE store_product_price_history (
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    effective_start_date DATE NOT NULL,
    list_price DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (store_id,product_id,effective_start_date),
    CONSTRAINT chk_store_price CHECK (list_price>=0),
    CONSTRAINT fk_store_price_inventory FOREIGN KEY (store_id,product_id) REFERENCES store_inventory (store_id,product_id)
);
CREATE TABLE store_supplier (
    store_id SMALLINT UNSIGNED NOT NULL,
    supplier_id SMALLINT UNSIGNED NOT NULL,
    delivery_days TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (store_id,supplier_id),
    CONSTRAINT chk_delivery_days CHECK (delivery_days BETWEEN 1 AND 7),
    CONSTRAINT fk_store_supplier_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_store_supplier_supplier FOREIGN KEY (supplier_id) REFERENCES supplier (supplier_id)
);
CREATE TABLE recipe (
    recipe_id INT UNSIGNED NOT NULL PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL UNIQUE,
    recipe_name VARCHAR(100) NOT NULL,
    preparation_minutes DECIMAL(6,2) NOT NULL,
    shelf_life_hours SMALLINT UNSIGNED NOT NULL,
    CONSTRAINT chk_recipe CHECK (preparation_minutes>0 AND shelf_life_hours BETWEEN 1 AND 72),
    CONSTRAINT fk_recipe_product FOREIGN KEY (product_id) REFERENCES product (product_id)
);
CREATE TABLE recipe_ingredient (
    recipe_id INT UNSIGNED NOT NULL,
    ingredient_product_id INT UNSIGNED NOT NULL,
    quantity_per_unit SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (recipe_id,ingredient_product_id),
    CONSTRAINT chk_recipe_quantity CHECK (quantity_per_unit>0),
    CONSTRAINT fk_recipe_ingredient_recipe FOREIGN KEY (recipe_id) REFERENCES recipe (recipe_id),
    CONSTRAINT fk_recipe_ingredient_product FOREIGN KEY (ingredient_product_id) REFERENCES product (product_id)
);
CREATE TABLE production_batch (
    production_batch_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    recipe_id INT UNSIGNED NOT NULL,
    production_method ENUM('MADE_TO_ORDER','BATCH') NOT NULL,
    scheduled_at DATETIME NOT NULL,
    started_at DATETIME NOT NULL,
    completed_at DATETIME NOT NULL,
    available_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    quantity_produced INT UNSIGNED NOT NULL,
    ingredient_cost DECIMAL(12,2) NOT NULL,
    packaging_cost DECIMAL(12,2) NOT NULL,
    labor_minutes DECIMAL(10,2) NOT NULL,
    sale_id BIGINT UNSIGNED NULL,
    sale_line_number SMALLINT UNSIGNED NULL,
    CONSTRAINT uq_production_sale UNIQUE (sale_id,sale_line_number),
    CONSTRAINT chk_production CHECK (quantity_produced>0 AND ingredient_cost>=0 AND packaging_cost>=0 AND labor_minutes>0
      AND scheduled_at<=started_at AND started_at<=completed_at AND completed_at<=available_at AND available_at<expires_at
      AND ((production_method='MADE_TO_ORDER' AND store_id=1 AND sale_id IS NOT NULL AND sale_line_number IS NOT NULL)
        OR (production_method='BATCH' AND store_id=2 AND sale_id IS NULL AND sale_line_number IS NULL))),
    CONSTRAINT fk_production_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_production_recipe FOREIGN KEY (recipe_id) REFERENCES recipe (recipe_id),
    CONSTRAINT fk_production_sale FOREIGN KEY (sale_id,sale_line_number) REFERENCES sale_item (sale_id,line_number)
);
CREATE TABLE production_input (
    production_batch_id BIGINT UNSIGNED NOT NULL,
    line_number SMALLINT UNSIGNED NOT NULL,
    ingredient_product_id INT UNSIGNED NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    cost_amount DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (production_batch_id,line_number),
    CONSTRAINT uq_production_ingredient UNIQUE (production_batch_id,ingredient_product_id),
    CONSTRAINT chk_production_input CHECK (line_number>0 AND quantity>0 AND cost_amount>=0),
    CONSTRAINT fk_input_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_input_product FOREIGN KEY (ingredient_product_id) REFERENCES product (product_id)
);
CREATE TABLE prepared_food_allocation (
    production_batch_id BIGINT UNSIGNED NOT NULL,
    sale_id BIGINT UNSIGNED NOT NULL,
    sale_line_number SMALLINT UNSIGNED NOT NULL,
    quantity SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (production_batch_id,sale_id,sale_line_number),
    CONSTRAINT chk_food_allocation CHECK (quantity>0),
    CONSTRAINT fk_allocation_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_allocation_sale FOREIGN KEY (sale_id,sale_line_number) REFERENCES sale_item (sale_id,line_number)
);
CREATE TABLE production_disposal (
    production_batch_id BIGINT UNSIGNED NOT NULL,
    adjustment_id BIGINT UNSIGNED NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    PRIMARY KEY (production_batch_id,adjustment_id),
    CONSTRAINT uq_disposal_adjustment UNIQUE (adjustment_id),
    CONSTRAINT chk_disposal_quantity CHECK (quantity>0),
    CONSTRAINT fk_disposal_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_disposal_adjustment FOREIGN KEY (adjustment_id) REFERENCES inventory_adjustment (adjustment_id)
);
CREATE TABLE daily_labor (
    store_id SMALLINT UNSIGNED NOT NULL,
    work_date DATE NOT NULL,
    department_id TINYINT UNSIGNED NOT NULL,
    job_role_id TINYINT UNSIGNED NOT NULL,
    paid_hours DECIMAL(8,2) NOT NULL,
    hourly_rate DECIMAL(7,2) NOT NULL,
    wage_amount DECIMAL(12,2) NOT NULL,
    employer_cost DECIMAL(12,2) NOT NULL,
    benefit_cost DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (store_id,work_date,department_id,job_role_id),
    CONSTRAINT chk_daily_labor CHECK (paid_hours>0 AND hourly_rate>0 AND wage_amount=ROUND(paid_hours*hourly_rate,2) AND employer_cost>=0 AND benefit_cost>=0),
    CONSTRAINT fk_labor_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_labor_department FOREIGN KEY (department_id) REFERENCES department (department_id),
    CONSTRAINT fk_labor_role FOREIGN KEY (job_role_id) REFERENCES job_role (job_role_id)
);
CREATE TABLE dataset_metadata (
    dataset_id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    edition ENUM('FIXTURE','CLASSROOM','FULL') NOT NULL,
    reporting_start DATE NOT NULL,
    reporting_end DATE NOT NULL,
    timezone_name VARCHAR(40) NOT NULL,
    seed INT UNSIGNED NOT NULL,
    CONSTRAINT chk_dataset CHECK (dataset_id=1 AND reporting_end>=reporting_start AND timezone_name='America/New_York')
);

CREATE TABLE inventory_movement (
    movement_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    store_id SMALLINT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    moved_at DATETIME NOT NULL,
    movement_type ENUM('SALE','RECEIPT','RETURN','ADJUSTMENT','PRODUCTION_IN','PRODUCTION_OUT') NOT NULL,
    quantity_change INT NOT NULL,
    value_change DECIMAL(14,2) NOT NULL,
    sale_id BIGINT UNSIGNED NULL,
    sale_line_number SMALLINT UNSIGNED NULL,
    receipt_id INT UNSIGNED NULL,
    receipt_line_number SMALLINT UNSIGNED NULL,
    sale_return_id BIGINT UNSIGNED NULL,
    return_line_number SMALLINT UNSIGNED NULL,
    adjustment_id BIGINT UNSIGNED NULL,
    production_batch_id BIGINT UNSIGNED NULL,
    production_input_line SMALLINT UNSIGNED NULL,
    CONSTRAINT uq_movement_production UNIQUE (production_batch_id,production_input_line),
    production_output_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN movement_type='PRODUCTION_IN' THEN production_batch_id ELSE NULL END) STORED,
    CONSTRAINT uq_production_output UNIQUE (production_output_id),
    CONSTRAINT uq_movement_sale UNIQUE (sale_id, sale_line_number),
    CONSTRAINT uq_movement_receipt UNIQUE (receipt_id, receipt_line_number),
    CONSTRAINT uq_movement_return UNIQUE (sale_return_id, return_line_number),
    CONSTRAINT uq_movement_adjustment UNIQUE (adjustment_id),
    CONSTRAINT chk_movement_sign CHECK (
        quantity_change <> 0 AND quantity_change * value_change >= 0
        AND (movement_type <> 'SALE' OR quantity_change < 0)
        AND (movement_type NOT IN ('RECEIPT','RETURN') OR quantity_change > 0)),
    CONSTRAINT chk_movement_source CHECK (
        (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='SALE' AND sale_id IS NOT NULL AND sale_line_number IS NOT NULL
         AND receipt_id IS NULL AND receipt_line_number IS NULL AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL)
        OR (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='RECEIPT' AND receipt_id IS NOT NULL AND receipt_line_number IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL)
        OR (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='RETURN' AND sale_return_id IS NOT NULL AND return_line_number IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL AND adjustment_id IS NULL)
        OR (production_batch_id IS NULL AND production_input_line IS NULL AND movement_type='ADJUSTMENT' AND adjustment_id IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL AND sale_return_id IS NULL AND return_line_number IS NULL)
        OR (movement_type='PRODUCTION_IN' AND production_batch_id IS NOT NULL AND production_input_line IS NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL
         AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL AND quantity_change>0)
        OR (movement_type='PRODUCTION_OUT' AND production_batch_id IS NOT NULL AND production_input_line IS NOT NULL
         AND sale_id IS NULL AND sale_line_number IS NULL AND receipt_id IS NULL AND receipt_line_number IS NULL
         AND sale_return_id IS NULL AND return_line_number IS NULL AND adjustment_id IS NULL AND quantity_change<0)),
    CONSTRAINT fk_movement_batch FOREIGN KEY (production_batch_id) REFERENCES production_batch (production_batch_id),
    CONSTRAINT fk_movement_input FOREIGN KEY (production_batch_id,production_input_line) REFERENCES production_input (production_batch_id,line_number),
    CONSTRAINT fk_movement_inventory FOREIGN KEY (store_id, product_id) REFERENCES store_inventory (store_id, product_id),
    CONSTRAINT fk_movement_sale FOREIGN KEY (sale_id, sale_line_number) REFERENCES sale_item (sale_id, line_number),
    CONSTRAINT fk_movement_receipt FOREIGN KEY (receipt_id, receipt_line_number) REFERENCES receipt_line (receipt_id, line_number),
    CONSTRAINT fk_movement_return FOREIGN KEY (sale_return_id, return_line_number) REFERENCES sale_return_item (sale_return_id, line_number),
    CONSTRAINT fk_movement_adjustment FOREIGN KEY (adjustment_id) REFERENCES inventory_adjustment (adjustment_id),
    INDEX idx_movement_inventory_date (store_id, product_id, moved_at, movement_id)
);
CREATE TABLE store_operating_expense (
    store_id SMALLINT UNSIGNED NOT NULL,
    expense_month DATE NOT NULL,
    expense_type ENUM('LABOR','PAYROLL_COST','BENEFITS','OCCUPANCY','UTILITIES','INSURANCE','MAINTENANCE','PROCESSING','EQUIPMENT','SUPPLIES','DEPRECIATION','LICENSES','OTHER') NOT NULL,
    full_store_budget DECIMAL(12,2) NOT NULL,
    allocation_rate DECIMAL(7,6) NOT NULL,
    allocated_amount DECIMAL(12,2) NOT NULL,
    assumption VARCHAR(255) NOT NULL,
    PRIMARY KEY (store_id, expense_month, expense_type),
    CONSTRAINT chk_expense CHECK (DAY(expense_month)=1 AND full_store_budget >= 0
        AND allocation_rate > 0 AND allocation_rate <= 1
        AND allocated_amount=ROUND(full_store_budget*allocation_rate,2)),
    CONSTRAINT fk_expense_store FOREIGN KEY (store_id) REFERENCES store (store_id)
);

-- Event grain: original posted line or subsequent negative return line.
-- RETURNED tickets are included on their sale date, then reversed on return date.
CREATE VIEW v_sales_activity AS
SELECT s.sale_id, l.line_number, s.store_id, s.customer_id, l.product_id,
       s.sold_at AS event_at, 'SALE' AS event_type,
       CAST(l.quantity AS SIGNED) AS units,
       l.quantity*l.unit_price AS gross_sales, l.discount_amount AS discounts,
       l.quantity*l.unit_price-l.discount_amount AS net_sales,
       l.tax_amount AS sales_tax, l.cost_amount AS cogs
FROM sale s JOIN sale_item l ON l.sale_id=s.sale_id
WHERE s.sale_status <> 'VOIDED'
UNION ALL
SELECT s.sale_id, l.sale_line_number, s.store_id, s.customer_id, original.product_id,
       r.returned_at, 'RETURN', -CAST(l.quantity AS SIGNED),
       -l.quantity*original.unit_price,
       -(l.quantity*original.unit_price-l.net_amount),
       -l.net_amount, -l.tax_amount, -l.cost_amount
FROM sale_return r JOIN sale_return_item l ON l.sale_return_id=r.sale_return_id
JOIN sale s ON s.sale_id=r.sale_id
JOIN sale_item original ON original.sale_id=l.sale_id AND original.line_number=l.sale_line_number;

CREATE VIEW v_monthly_store_financial AS
SELECT store_id, DATE_FORMAT(event_at,'%Y-%m-01') AS month_start,
       SUM(net_sales) AS net_sales, SUM(cogs) AS cogs,
       SUM(net_sales-cogs) AS gross_profit, SUM(sales_tax) AS sales_tax
FROM v_sales_activity GROUP BY store_id, DATE_FORMAT(event_at,'%Y-%m-01');


-- Operating income before financing and income tax; stock losses are expensed once.
CREATE VIEW v_monthly_store_income AS
SELECT f.store_id,f.month_start,f.net_sales,f.cogs,f.gross_profit,
       COALESCE(e.expenses,0) AS recorded_operating_expenses,
       COALESCE(w.inventory_loss,0) AS inventory_loss,
       f.gross_profit-COALESCE(e.expenses,0)-COALESCE(w.inventory_loss,0) AS operating_profit,
       ROUND(100*(f.gross_profit-COALESCE(e.expenses,0)-COALESCE(w.inventory_loss,0))/NULLIF(f.net_sales,0),2) AS operating_margin_pct
FROM v_monthly_store_financial f
LEFT JOIN (SELECT store_id,expense_month,SUM(allocated_amount) expenses FROM store_operating_expense GROUP BY store_id,expense_month) e
 ON e.store_id=f.store_id AND e.expense_month=f.month_start
LEFT JOIN (SELECT store_id,DATE_FORMAT(moved_at,'%Y-%m-01') month_start,-SUM(value_change) inventory_loss FROM inventory_movement
 WHERE movement_type='ADJUSTMENT' GROUP BY store_id,DATE_FORMAT(moved_at,'%Y-%m-01')) w ON w.store_id=f.store_id AND w.month_start=f.month_start;
