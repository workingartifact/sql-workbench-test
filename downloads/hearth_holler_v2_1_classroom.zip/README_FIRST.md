# Hearth & Holler v2.1 — CLASSROOM

AN/MKT 324. Reporting period: 2025-01-01 through 2025-03-31. 127,376 recorded tickets; 674,041 lines.

Read STUDENT_INSTALLATION.md. Install 01_create_schema.sql then 02_insert_data.sql. Run 06_verify_installation.sql and 07_first_day_queries.sql. No Python required. This edition uses schema hearth_holler_grocery_v21; do not load both editions into the same schema.

Validated on Windows MySQL Server 8.4.11 through the command-line client. macOS and Workbench GUI steps are not tested. Instructor answer keys are separate. Both editions use the same validated model. Fictional business assumptions and accounting boundaries are disclosed in MODEL_ASSUMPTIONS.md.
