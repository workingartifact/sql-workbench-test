-- Hearth & Holler v2.1 | AN/MKT 324 | Student exercises; no numerical answers
-- Read dataset_metadata for your reporting period. Some historical comparisons require FULL.
USE hearth_holler_grocery_v21;

-- LEVEL 1 | Q01: List the two Lexington stores by store number.

-- LEVEL 1 | Q02: Show the first 20 catalog products alphabetically.

-- LEVEL 1 | Q03: Show the 20 cheapest active products under $4.

-- LEVEL 1 | Q04: Which distinct customer cities and states are recorded?

-- LEVEL 1 | Q05: Show the ten largest original tickets, including audit-only voids.

-- LEVEL 1 | Q06: Find the first 20 products with Meeting in the name.

-- LEVEL 1 | Q07: List all fictional brands and taglines alphabetically.

-- LEVEL 1 | Q08: Find active employees hired in 2022 or 2023.

-- LEVEL 1 | Q09: List suppliers rated at least 4.5 with lead time no more than five days.

-- LEVEL 1 | Q10: List promotions intersecting the installed reporting period.

-- LEVEL 1 | Q11: Show 20 store-products at or below reorder point.

-- LEVEL 1 | Q12: Show the first 20 anonymous tickets.

-- LEVEL 2 | Q13: Count products and compare minimum, maximum, and average current retail prices.

-- LEVEL 2 | Q14: Count registered customers by city.

-- LEVEL 2 | Q15: Count employees in each store, including current active employees.

-- LEVEL 2 | Q16: Which job roles have mean pay above $20?

-- LEVEL 2 | Q17: How many sales have each closing status?

-- LEVEL 2 | Q18: What is the average original posted customer transaction, before and including tax?

-- LEVEL 2 | Q19: How many posted tickets occurred each month?

-- LEVEL 2 | Q20: How many purchase orders have reached each status?

-- LEVEL 2 | Q21: Which stores have more than 500 currently available stocked products?

-- LEVEL 2 | Q22: How many loyalty events and signed points occur by event type?

-- LEVEL 2 | Q23: How many distinct basket lines occur most often?

-- LEVEL 2 | Q24: What gross merchandise sales, discounts, returns, net sales, tax, COGS, and gross profit does the reporting period record?

-- LEVEL 3 | Q25: Show employee names with store, role, and optional department.

-- LEVEL 3 | Q26: Which customers have no identified posted purchase in the reporting period? Show count.

-- LEVEL 3 | Q27: Which products have never appeared on a posted sale? Show first 20.

-- LEVEL 3 | Q28: Which suppliers offer the original Black-Tie Black Beans?

-- LEVEL 3 | Q29: Show the original receipt for sale 125.

-- LEVEL 3 | Q30: Show each employee and their optional manager.

-- LEVEL 3 | Q31: How many original posted tickets use split tender in each store?

-- LEVEL 3 | Q32: Show ordered, received, and outstanding quantities for the first 20 PO lines.

-- LEVEL 3 | Q33: Which categories have average current price above the overall catalog average?

-- LEVEL 3 | Q34: Which original dessert products are stocked at which stores?

-- LEVEL 3 | Q35: Show the ten customers with the most identified posted visits.

-- LEVEL 3 | Q36: Which five suppliers offer the broadest assortment?

-- LEVEL 4 | Q37: Which Lexington store generates the most net revenue after dated returns?

-- LEVEL 4 | Q38: Which ten products contribute the most gross profit?

-- LEVEL 4 | Q39: Which categories have the lowest gross margins?

-- LEVEL 4 | Q40: What percentage of net sales comes from customers who were loyalty members at checkout?

-- LEVEL 4 | Q41: Compare supplier quotes at the start and end of the installed period.

-- LEVEL 4 | Q42: Reconcile opening stock, receipts, sales, returns, production, ingredient usage and ending stock by store.

-- LEVEL 4 | Q43: Which products are at risk of running out, considering open purchase commitments? Show 20.

-- LEVEL 4 | Q44: What are supplier lead times and on-time completion rates for fully received POs?

-- LEVEL 4 | Q45: How much original tender and refunded tender used each method?

-- LEVEL 4 | Q46: What were commitments, receipts at agreed cost, and unreceived commitments excluding cancelled orders?

-- LEVEL 4 | Q47: Calculate operating income after recurring expenses and inventory losses, before financing and income tax.

-- LEVEL 4 | Q48: Compare weekday and weekend original posted ticket values by store.

-- LEVEL 5 | Q49: Report monthly net sales with month-over-month change and running total.

-- LEVEL 5 | Q50: Rank revenue and gross profit for the ten highest-revenue products. Do ranks match?

-- LEVEL 5 | Q51: Full edition: compare January-September revenue and operating contribution across years. One-year editions have no prior-year comparison.

-- LEVEL 5 | Q52: Show the top two gross-profit products within each category.

-- LEVEL 5 | Q53: Show the first 20 point events and running balances for account 1.

-- LEVEL 5 | Q54: Count customers in period purchasing-frequency bands, including zero visits.

-- LEVEL 5 | Q55: Measure next-month repeat participation by first observed purchase cohort, excluding the final reporting month.

-- LEVEL 5 | Q56: Generate a complete January 2025 daily calendar and a seven-day rolling net-sales average.

-- LEVEL 5 | Q57: Compare current product cost estimates with actual realized moving-average COGS for 20 products.

-- LEVEL 5 | Q58: Find the ten slowest active sellable products by posted units during the last 90 reporting days.

-- LEVEL 5 | Q59: Show the first 20 inventory movements and resulting balances for store 1 product 1.

-- LEVEL 5 | Q60: Calculate annualized inventory turnover using time-weighted carrying value for the installed period.

-- LEVEL 3 | Q61: Show each store operating schedule, including midnight closing.

-- LEVEL 3 | Q62: Count transactions by store, weekday and hour.

-- LEVEL 3 | Q63: Compare transaction values by shopping occasion.

-- LEVEL 3 | Q64: Compare breakfast and lunch food units by store and hour.

-- LEVEL 3 | Q65: Measure bar revenue by weekday and hour.

-- LEVEL 3 | Q66: Compare average basket lines on Saturday and Tuesday.

-- LEVEL 5 | Q67: Compare production quantities and ingredient/packaging costs by method.

-- LEVEL 5 | Q68: Compare prepared-food waste rates by store and recipe.

-- LEVEL 5 | Q69: Show breakfast product gross profit before labor.

-- LEVEL 5 | Q70: Compare recipe input unit costs by month.

-- LEVEL 5 | Q71: Calculate labor cost by store and department.

-- LEVEL 5 | Q72: Show monthly operating-income statements.

-- LEVEL 5 | Q73: Compare sales and margin across grocery, griddle, grab-and-go and bar channels.

-- LEVEL 5 | Q74: Measure the share of posted sales during each store's three busiest hours.

-- LEVEL 5 | Q75: Find price differences for shared products on the final reporting day.

-- LEVEL 5 | Q76: Show pre-opening batch production.

-- LEVEL 5 | Q77: Find posted tickets containing both bar and grocery items.

-- LEVEL 5 | Q78: Compare taxable and exempt original merchandise sales.

-- LEVEL 5 | Q79: Compare monthly shrink and prepared-food disposal values.

-- LEVEL 5 | Q80: Identify operating-loss months and explain which expense categories matter.
